import type { Config } from 'tailwindcss';

/**
 * @openticket/ui — Base Tailwind config
 * Verticals extend this config with their own theme overrides.
 *
 * Usage in vertical tailwind.config.ts:
 *   import baseConfig from '@openticket/ui/tailwind.config';
 *   export default { ...baseConfig, content: [...], theme: { extend: { ...baseConfig.theme?.extend, ... } } }
 */
const config: Config = {
  content: [],
  theme: {
    extend: {
      /**
       * Brand color tokens — Brand Book §3 / Design System §1.
       * shadcn semantic vars (hsl, alpha-channel ready) map the components
       * (bg-primary, text-foreground, border-border, …). The `brand` namespace
       * exposes the raw OpenTicket palette (bg-brand-cyan, text-brand-amber, …).
       * Defined as HSL in src/theme.css — values, not names, carry the brand.
       */
      colors: {
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        success: {
          DEFAULT: 'hsl(var(--success))',
          foreground: 'hsl(var(--success-foreground))',
        },
        warning: {
          DEFAULT: 'hsl(var(--warning))',
          foreground: 'hsl(var(--warning-foreground))',
        },
        info: {
          DEFAULT: 'hsl(var(--info))',
          foreground: 'hsl(var(--info-foreground))',
        },
        // Raw OpenTicket palette (Brand Book §3) — hubs, gradients, accents.
        brand: {
          purple: 'hsl(var(--brand-purple))',                 // #a855f7  --pri
          'purple-light': 'hsl(var(--brand-purple-light))',   // #c084fc  --pri2
          cyan: 'hsl(var(--brand-cyan))',                     // #22d3ee  --cy
          amber: 'hsl(var(--brand-amber))',                   // #fbbf24  --am
          green: 'hsl(var(--brand-green))',                   // #22c55e  --gd
          orange: 'hsl(var(--brand-orange))',                 // #f97316  --or
        },
      },
      borderRadius: {
        lg: 'var(--radius)',                 // 8px  Card/Alert
        md: 'calc(var(--radius) - 2px)',     // 6px  Button/Input/Select
        sm: 'calc(var(--radius) - 4px)',     // 4px  Checkbox/menu items
      },
      fontFamily: {
        sans: ['var(--font-sans)'],
        heading: ['var(--font-heading)'],
        mono: ['var(--font-mono)'],
      },
      backgroundImage: {
        // Brand Book §3: gradient assinatura — cyan → purple-light → amber, 90deg.
        'brand-gradient':
          'linear-gradient(90deg, hsl(var(--brand-cyan)), hsl(var(--brand-purple-light)), hsl(var(--brand-amber)))',
      },
      keyframes: {
        'glow-pulse': {
          '0%, 100%': { boxShadow: '0 0 8px 2px rgba(249,115,22,0.3)' },
          '50%': { boxShadow: '0 0 20px 6px rgba(249,115,22,0.5)' },
        },
        'counter-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'bar-fill': {
          '0%': { width: '0%' },
          '100%': { width: 'var(--bar-width)' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      animation: {
        'glow-pulse': 'glow-pulse 2s ease-in-out infinite',
        'counter-up': 'counter-up 0.5s ease-out forwards',
        shimmer: 'shimmer 2s linear infinite',
        'bar-fill': 'bar-fill 1s ease-out forwards',
        'fade-up': 'fade-up 0.4s ease-out forwards',
      },
    },
  },
  plugins: [],
};

export default config;
