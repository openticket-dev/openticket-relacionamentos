"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import type { TourStep } from "./tour-overlay";

export type { TourStep } from "./tour-overlay";

const STORAGE_PREFIX = "ot_tour_seen_";

function getSeenTours(scope: string): Record<string, boolean> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(STORAGE_PREFIX + scope) || "{}");
  } catch {
    return {};
  }
}

function markTourSeen(scope: string, pageId: string) {
  if (typeof window === "undefined") return;
  const seen = getSeenTours(scope);
  seen[pageId] = true;
  localStorage.setItem(STORAGE_PREFIX + scope, JSON.stringify(seen));
}

export function useTour(scope: string, pageId: string, steps: TourStep[]) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [active, setActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (searchParams?.get("tour") === "true") {
      setActive(true);
      setCurrentStep(0);
    }
  }, [searchParams]);

  const clearQuery = useCallback(() => {
    if (!pathname) return;
    router.replace(pathname);
  }, [router, pathname]);

  const next = useCallback(() => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((p) => p + 1);
    } else {
      setActive(false);
      setCurrentStep(0);
      markTourSeen(scope, pageId);
      clearQuery();
    }
  }, [currentStep, steps.length, scope, pageId, clearQuery]);

  const prev = useCallback(() => {
    if (currentStep > 0) setCurrentStep((p) => p - 1);
  }, [currentStep]);

  const skip = useCallback(() => {
    setActive(false);
    setCurrentStep(0);
    markTourSeen(scope, pageId);
    clearQuery();
  }, [scope, pageId, clearQuery]);

  return {
    active,
    currentStep,
    step: steps[currentStep] || null,
    totalSteps: steps.length,
    next,
    prev,
    skip,
    isSeen: () => getSeenTours(scope)[pageId] === true,
  };
}
