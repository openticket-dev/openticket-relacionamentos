import type { Meta, StoryObj } from '@storybook/react';
import ErrorState from './error-state';

/**
 * ErrorState — exibe erro recuperavel com botao de retry.
 */
const meta: Meta<typeof ErrorState> = {
  title: 'States/ErrorState',
  component: ErrorState,
  tags: ['autodocs'],
  parameters: { a11y: { disable: false } },
};

export default meta;
type Story = StoryObj<typeof ErrorState>;

export const Padrao: Story = {
  args: {
    onRetry: () => {
      /* handler real vem do consumidor */
    },
  },
};

export const Customizado: Story = {
  args: {
    title: 'Falha ao carregar eventos',
    message: 'Verifique sua conexao e tente novamente.',
    onRetry: () => {
      /* handler real vem do consumidor */
    },
  },
};

export const SemRetry: Story = {
  args: {
    title: 'Erro permanente',
    message: 'Esse recurso foi descontinuado.',
  },
};
