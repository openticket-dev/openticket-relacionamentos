import type { Meta, StoryObj } from '@storybook/react';
import { Badge } from './badge';

/**
 * Badge — labels e status pills usados em listagens de eventos, ingressos e parceiros.
 */
const meta: Meta<typeof Badge> = {
  title: 'Primitives/Badge',
  component: Badge,
  tags: ['autodocs'],
  parameters: {
    a11y: { disable: false },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'secondary', 'destructive', 'outline'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Badge>;

export const Default: Story = {
  args: { children: 'Em alta' },
};

export const Secondary: Story = {
  args: { variant: 'secondary', children: 'Pre-venda' },
};

export const Destructive: Story = {
  args: { variant: 'destructive', children: 'Esgotado' },
};

export const Outline: Story = {
  args: { variant: 'outline', children: 'Gratuito' },
};
