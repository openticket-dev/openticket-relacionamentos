// @openticket-dev/ui — Shared UI Components
// Extracted from gastronomy (superset of 41 components) + admin layout

export * from './lib/utils';

// Admin layout (Onda 2 Phase 2 — shared sidebar/header for all verticals)
export * from './admin';

export * from './accordion';
export * from './alert';
export * from './alert-dialog';
export * from './aspect-ratio';
export * from './avatar';
export * from './badge';
export * from './breadcrumb';
export * from './button';
export * from './card';
export * from './checkbox';
export * from './collapsible';
export * from './context-menu';
export * from './dialog';
export * from './dropdown-menu';
export * from './empty-state';
export * from './error-state';
export * from './hover-card';
export * from './input';
export * from './label';
export * from './menubar';
export * from './navigation-menu';
export * from './open-ticket-logo';
export * from './pagination';
export * from './popover';
export * from './progress';
export * from './radio-group';
export * from './scroll-area';
export * from './select';
export * from './separator';
export * from './sheet';
export * from './skeleton';
export * from './slider';
export * from './success-state';
export * from './switch';
export * from './table';
export * from './tabs';
export * from './textarea';
export * from './toggle';
export * from './toggle-group';
export * from './tooltip';

// Wave 7 — Footer System (chameleon base + verticals)
export * from './Footer';

// Wave 13 — Vertical Sidebar Switcher
export * from './SidebarSwitcher';

// Fase 0 (port _legacy admin) — shared primitives extraídas dos Vites legados
export * from './tour-overlay';
export * from './use-tour';
export * from './themes';
export * from './coming-soon';
