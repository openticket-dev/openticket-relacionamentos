import {
  useCallback,
  useRef,
  type KeyboardEvent,
} from "react";
import { cn } from '../lib/utils';
import { VerticalCard } from './VerticalCard';
import {
  VERTICAL_ORDER,
  VERTICAL_THEMES,
  type Vertical,
} from './types';

export interface SidebarSwitcherProps {
  /** Vertical ativa atualmente (ex: 'eventos'). Null = nenhuma destacada */
  activeVertical: Vertical | null;
  /** Callback quando user clica num card. Se omitido, cards renderizam como <a href={theme.href}> */
  onSelect?: (vertical: Vertical) => void;
  /** Posicao do sidebar. Default 'left' (CEO confirmou 2026-04-21 — direita reservada pro Perfil Camaleao) */
  position?: 'left' | 'right';
  /** Posicionamento CSS. Default 'fixed' = sempre visivel; 'sticky' = scroll com pagina */
  variant?: 'fixed' | 'sticky';
  /** Largura do sidebar em px. Default 160 */
  width?: number;
  /** Offset top em px (altura do nav superior). Default 64 */
  topOffset?: number;
  /** Override de href por vertical (caso o app queira rotas customizadas) */
  hrefOverrides?: Partial<Record<Vertical, string>>;
  /** ClassName extra pro container */
  className?: string;
  /** Renderiza como <a> (nav SSR-friendly) ou <button> (controlled). Default 'button' se onSelect, senao 'a' */
  cardAs?: 'button' | 'a';
}

/**
 * Wave 13 — Vertical Sidebar Switcher
 *
 * Sidebar lateral fixa com 7 cards (verticais OpenTicket).
 * Ref: kuffinho-masterplan.md WAVE 13 (linhas 1231-1407).
 *
 * Decisoes CEO 2026-04-21:
 * - 7 cards (Todos REMOVIDO)
 * - Posicao: ESQUERDA (direita = Perfil Camaleao)
 * - Sempre expandido, so nome (sem icone, sem tagline)
 * - Cards retangulares minimalistas
 *
 * Uso basico (controlled):
 * ```tsx
 * const [vertical, setVertical] = useState<Vertical>('eventos');
 * <SidebarSwitcher activeVertical={vertical} onSelect={setVertical} />
 * ```
 *
 * Uso com Next router (uncontrolled, links HTML):
 * ```tsx
 * const pathname = usePathname();
 * const active = inferVerticalFromPath(pathname);
 * <SidebarSwitcher activeVertical={active} />
 * ```
 *
 * A11y:
 * - role="navigation" + aria-label
 * - aria-current="page" no card ativo
 * - keyboard nav nativo (Tab + Enter/Space, ou click em <a>)
 */
export function SidebarSwitcher({
  activeVertical,
  onSelect,
  position = 'left',
  variant = 'fixed',
  width = 160,
  topOffset = 64,
  hrefOverrides,
  className,
  cardAs,
}: SidebarSwitcherProps) {
  const renderAs: 'button' | 'a' = cardAs ?? (onSelect ? 'button' : 'a');

  // Keyboard arrow nav entre cards (cumpre SPRINT-13.7 — A11y)
  const containerRef = useRef<HTMLElement>(null);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    const root = containerRef.current;
    if (!root) return;

    const cards = Array.from(
      root.querySelectorAll<HTMLElement>('[data-vertical]')
    );
    const currentIndex = cards.findIndex(
      (el) => el === document.activeElement
    );
    if (currentIndex === -1) return;

    e.preventDefault();
    const delta = e.key === 'ArrowDown' ? 1 : -1;
    const nextIndex = (currentIndex + delta + cards.length) % cards.length;
    cards[nextIndex]?.focus();
  }, []);

  const positionClasses =
    variant === 'fixed'
      ? cn(
          'fixed bottom-0 z-40',
          position === 'left' ? 'left-0' : 'right-0'
        )
      : cn('sticky', position === 'left' ? 'self-start' : 'self-end');

  return (
    <nav
      ref={containerRef}
      role="navigation"
      aria-label="Verticais da plataforma"
      onKeyDown={handleKeyDown}
      className={cn(
        positionClasses,
        'flex flex-col bg-neutral-950/95 backdrop-blur-sm border-r border-white/10',
        position === 'right' && 'border-l border-r-0',
        className
      )}
      style={{
        width,
        top: variant === 'fixed' ? topOffset : undefined,
      }}
      data-sidebar-switcher
      data-position={position}
    >
      {VERTICAL_ORDER.map((slug) => {
        const theme = VERTICAL_THEMES[slug];
        const href = hrefOverrides?.[slug] ?? theme.href;
        return (
          <VerticalCard
            key={slug}
            theme={theme}
            active={activeVertical === slug}
            onClick={onSelect}
            as={renderAs}
            href={href}
          />
        );
      })}
    </nav>
  );
}
