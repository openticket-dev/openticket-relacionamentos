import { VERTICAL_THEMES, type Vertical, type VerticalThemeEntry } from './types';

/**
 * Hook que retorna o tema (cor + icone + slug + href) de uma vertical.
 * Exemplo: const theme = useVerticalTheme('eventos');
 *          theme.accent === '#a855f7'
 */
export function useVerticalTheme(vertical: Vertical): VerticalThemeEntry {
  const theme = VERTICAL_THEMES[vertical];
  if (!theme) {
    throw new Error(`[useVerticalTheme] Vertical desconhecida: ${vertical}`);
  }
  return theme;
}

/**
 * Resolve a vertical ativa a partir de um pathname (Next.js / React Router).
 * Retorna null se nenhuma vertical bate (ex: /login, /onboarding).
 */
export function inferVerticalFromPath(pathname: string): Vertical | null {
  const slugs = Object.keys(VERTICAL_THEMES) as Vertical[];
  for (const slug of slugs) {
    if (pathname === `/${slug}` || pathname.startsWith(`/${slug}/`)) {
      return slug;
    }
  }
  return null;
}
