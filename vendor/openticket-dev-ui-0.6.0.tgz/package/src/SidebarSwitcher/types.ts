// Wave 13 — Vertical Sidebar Switcher
// 7 verticais (Todos REMOVIDO conforme decisao CEO 2026-04-21)

export type Vertical =
  | 'eventos'
  | 'gastronomia'
  | 'esportes'
  | 'varejo'
  | 'cultura'
  | 'igreja'
  | 'educacao';

export interface VerticalThemeEntry {
  /** slug usado em rotas e identificacao */
  slug: Vertical;
  /** label exibido no card (PT-BR) */
  label: string;
  /** cor hex de acento (active state + lateral bar) */
  accent: string;
  /** nome do icone lucide (consumidor pode importar dinamicamente se quiser) */
  icon:
    | 'CalendarDays'
    | 'UtensilsCrossed'
    | 'Trophy'
    | 'Store'
    | 'Palette'
    | 'Church'
    | 'GraduationCap';
  /** href padrao (consumidor pode override via onSelect) */
  href: string;
}

/**
 * Tema canonico das 7 verticais.
 * Referencia: kuffinho-masterplan.md WAVE 13 (linhas 1330-1340).
 * Cores fixas — NAO alterar sem aprovacao CEO.
 */
export const VERTICAL_THEMES: Record<Vertical, VerticalThemeEntry> = {
  eventos: {
    slug: 'eventos',
    label: 'Eventos',
    accent: '#a855f7',
    icon: 'CalendarDays',
    href: '/eventos',
  },
  gastronomia: {
    slug: 'gastronomia',
    label: 'Gastronomia',
    accent: '#f97316',
    icon: 'UtensilsCrossed',
    href: '/gastronomia',
  },
  esportes: {
    slug: 'esportes',
    label: 'Esportes',
    accent: '#22c55e',
    icon: 'Trophy',
    href: '/esportes',
  },
  varejo: {
    slug: 'varejo',
    label: 'Varejo',
    accent: '#3b82f6',
    icon: 'Store',
    href: '/varejo',
  },
  cultura: {
    slug: 'cultura',
    label: 'Cultura',
    accent: '#ec4899',
    icon: 'Palette',
    href: '/cultura',
  },
  igreja: {
    slug: 'igreja',
    label: 'Igreja',
    accent: '#d4af37',
    icon: 'Church',
    href: '/igreja',
  },
  educacao: {
    slug: 'educacao',
    label: 'Educacao',
    accent: '#f59e0b',
    icon: 'GraduationCap',
    href: '/educacao',
  },
};

/** Ordem canonica de renderizacao no sidebar */
export const VERTICAL_ORDER: Vertical[] = [
  'eventos',
  'gastronomia',
  'esportes',
  'varejo',
  'cultura',
  'igreja',
  'educacao',
];
