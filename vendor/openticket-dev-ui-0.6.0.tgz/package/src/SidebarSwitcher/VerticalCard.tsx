import {
  forwardRef,
  useCallback,
  type CSSProperties,
  type MouseEvent,
  type Ref,
} from "react";
import { cn } from '../lib/utils';
import type { VerticalThemeEntry } from './types';

export interface VerticalCardProps {
  theme: VerticalThemeEntry;
  active: boolean;
  onClick?: (slug: VerticalThemeEntry['slug']) => void;
  /** Renderizar como link (<a>) em vez de button. Util quando consumidor quer SSR-friendly nav */
  as?: 'button' | 'a';
  /** href quando as='a' (sobrescreve theme.href) */
  href?: string;
}

/**
 * Card individual de uma vertical no sidebar.
 * Decisoes CEO 2026-04-21:
 * - Apenas nome (sem icone, sem tagline)
 * - Active: gradient accent + texto branco bold + barra lateral 3px colorida
 * - Hover: bg white/5 sutil, transition 150ms
 */
export const VerticalCard = forwardRef<HTMLElement, VerticalCardProps>(
  ({ theme, active, onClick, as = 'button', href }, ref) => {
    const handleClick = useCallback(
      (e: MouseEvent) => {
        if (onClick) {
          e.preventDefault();
          onClick(theme.slug);
        }
      },
      [onClick, theme.slug]
    );

    const baseClasses = cn(
      'relative flex items-center w-full px-5 py-3.5 min-h-[48px]',
      'text-left text-sm font-medium tracking-normal',
      'border-b border-white/5 last:border-b-0',
      'transition-all duration-150 ease-out',
      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/20',
      active
        ? 'text-white font-semibold'
        : 'text-neutral-300 hover:text-white hover:bg-white/5'
    );

    // Active: gradient + barra lateral colorida via inline style (cores dinamicas por vertical)
    const activeStyle: CSSProperties | undefined = active
      ? {
          background: `linear-gradient(90deg, ${theme.accent}26 0%, ${theme.accent}0d 60%, transparent 100%)`,
        }
      : undefined;

    const content = (
      <>
        {/* Barra lateral esquerda colorida (active state) */}
        {active && (
          <span
            aria-hidden="true"
            className="absolute left-0 top-0 bottom-0 w-[3px]"
            style={{ backgroundColor: theme.accent }}
          />
        )}
        <span className="relative z-10">{theme.label}</span>
      </>
    );

    if (as === 'a') {
      return (
        <a
          ref={ref as Ref<HTMLAnchorElement>}
          href={href ?? theme.href}
          onClick={handleClick}
          className={baseClasses}
          style={activeStyle}
          aria-current={active ? 'page' : undefined}
          data-vertical={theme.slug}
        >
          {content}
        </a>
      );
    }

    return (
      <button
        ref={ref as Ref<HTMLButtonElement>}
        type="button"
        onClick={handleClick}
        className={baseClasses}
        style={activeStyle}
        aria-current={active ? 'page' : undefined}
        data-vertical={theme.slug}
      >
        {content}
      </button>
    );
  }
);

VerticalCard.displayName = 'VerticalCard';
