import type { Meta, StoryObj } from '@storybook/react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from './card';
import { Button } from './button';

/**
 * Card — container base de eventos, ingressos e dashboards.
 */
const meta: Meta<typeof Card> = {
  title: 'Layout/Card',
  component: Card,
  tags: ['autodocs'],
  parameters: { a11y: { disable: false } },
};

export default meta;
type Story = StoryObj<typeof Card>;

export const EventoCard: Story = {
  render: () => (
    <Card className="w-[360px]">
      <CardHeader>
        <CardTitle>Festival Spaceship 2026</CardTitle>
        <CardDescription>Sao Paulo · 12 de Junho · 19h</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">
          Lineup completo + experiencias 3D imersivas. Lote promocional ate 30/04.
        </p>
      </CardContent>
      <CardFooter className="justify-between">
        <span className="text-sm font-medium">A partir de R$ 89</span>
        <Button size="sm">Comprar</Button>
      </CardFooter>
    </Card>
  ),
};

export const Minimo: Story = {
  render: () => (
    <Card className="w-[280px]">
      <CardHeader>
        <CardTitle>Card minimo</CardTitle>
      </CardHeader>
      <CardContent>Sem descricao, sem footer.</CardContent>
    </Card>
  ),
};
