import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './button';

/**
 * Button — variantes shadcn (default, destructive, outline, secondary, ghost, link)
 * + 4 sizes (default, sm, lg, icon).
 *
 * A11y: focus ring visible, disabled state announced.
 */
const meta: Meta<typeof Button> = {
  title: 'Primitives/Button',
  component: Button,
  tags: ['autodocs'],
  parameters: {
    a11y: { disable: false },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'destructive', 'outline', 'secondary', 'ghost', 'link'],
    },
    size: {
      control: 'select',
      options: ['default', 'sm', 'lg', 'icon'],
    },
    disabled: { control: 'boolean' },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

export const Default: Story = {
  args: { children: 'Comprar ingresso' },
};

export const Destructive: Story = {
  args: { variant: 'destructive', children: 'Cancelar evento' },
};

export const Outline: Story = {
  args: { variant: 'outline', children: 'Ver detalhes' },
};

export const Secondary: Story = {
  args: { variant: 'secondary', children: 'Compartilhar' },
};

export const Ghost: Story = {
  args: { variant: 'ghost', children: 'Voltar' },
};

export const Link: Story = {
  args: { variant: 'link', children: 'Saiba mais' },
};

export const Small: Story = {
  args: { size: 'sm', children: 'Pequeno' },
};

export const Large: Story = {
  args: { size: 'lg', children: 'Comprar agora' },
};

export const Disabled: Story = {
  args: { disabled: true, children: 'Indisponivel' },
};
