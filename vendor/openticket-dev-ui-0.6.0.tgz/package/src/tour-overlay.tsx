"use client";

import React, { useEffect, useRef, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

export type TourStep = {
  target: string;
  title: string;
  description: string;
  placement?: "top" | "bottom" | "left" | "right";
};

type Props = {
  active: boolean;
  step: TourStep | null;
  currentStep: number;
  totalSteps: number;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
  accentColor?: string;
};

export function TourOverlay({
  active,
  step,
  currentStep,
  totalSteps,
  onNext,
  onPrev,
  onSkip,
  accentColor = "#6366f1",
}: Props) {
  const [rect, setRect] = useState<DOMRect | null>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!active || !step) {
      setRect(null);
      return;
    }
    const el = document.querySelector(`[data-tour="${step.target}"]`);
    if (!el) {
      setRect(null);
      return;
    }
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    const t = setTimeout(() => setRect(el.getBoundingClientRect()), 300);
    return () => clearTimeout(t);
  }, [active, step]);

  useEffect(() => {
    if (!active || !step) return;
    const handler = () => {
      const el = document.querySelector(`[data-tour="${step.target}"]`);
      if (el) setRect(el.getBoundingClientRect());
    };
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, [active, step]);

  if (!active || !step) return null;

  const padding = 8;
  const highlightStyle = rect
    ? {
        top: rect.top - padding + window.scrollY,
        left: rect.left - padding,
        width: rect.width + padding * 2,
        height: rect.height + padding * 2,
      }
    : null;

  const placement = step.placement || "bottom";
  let tooltipStyle: React.CSSProperties = {};
  if (rect) {
    const gap = 16;
    switch (placement) {
      case "bottom":
        tooltipStyle = {
          top: rect.bottom + gap + window.scrollY,
          left: Math.max(16, rect.left + rect.width / 2 - 180),
        };
        break;
      case "top":
        tooltipStyle = {
          top: rect.top - gap - 160 + window.scrollY,
          left: Math.max(16, rect.left + rect.width / 2 - 180),
        };
        break;
      case "left":
        tooltipStyle = {
          top: rect.top + rect.height / 2 - 60 + window.scrollY,
          left: Math.max(16, rect.left - 376),
        };
        break;
      case "right":
        tooltipStyle = {
          top: rect.top + rect.height / 2 - 60 + window.scrollY,
          left: rect.right + gap,
        };
        break;
    }
  }

  return (
    <div className="fixed inset-0 z-[9999]" style={{ pointerEvents: "none" }}>
      <div
        className="absolute inset-0"
        style={{ background: "rgba(0,0,0,0.6)", pointerEvents: "auto" }}
        onClick={onSkip}
      />
      {highlightStyle && (
        <div
          className="absolute rounded-xl"
          style={{
            ...highlightStyle,
            boxShadow: `0 0 0 4px ${accentColor}40, 0 0 0 9999px rgba(0,0,0,0.6)`,
            background: "transparent",
            zIndex: 1,
            pointerEvents: "none",
          }}
        />
      )}
      <div
        ref={tooltipRef}
        className="absolute w-[360px] rounded-xl p-5 shadow-2xl"
        style={{
          ...tooltipStyle,
          background: "#18181b",
          border: `1px solid ${accentColor}40`,
          zIndex: 2,
          pointerEvents: "auto",
        }}
      >
        <button
          onClick={onSkip}
          aria-label="Fechar tour"
          className="absolute top-3 right-3 p-1 rounded-lg hover:bg-white/10 text-zinc-500 hover:text-white transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-2 mb-3">
          <span
            className="text-[10px] font-bold px-2 py-0.5 rounded-full"
            style={{ background: `${accentColor}20`, color: accentColor }}
          >
            {currentStep + 1}/{totalSteps}
          </span>
        </div>
        <h3 className="text-sm font-bold text-white mb-1.5">{step.title}</h3>
        <p className="text-xs text-zinc-400 leading-relaxed mb-4">
          {step.description}
        </p>
        <div className="flex items-center gap-1.5 mb-4">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className="h-1.5 rounded-full transition-all duration-300"
              style={{
                width: i === currentStep ? 20 : 8,
                background: i === currentStep ? accentColor : "#3f3f46",
              }}
            />
          ))}
        </div>
        <div className="flex items-center justify-between">
          <button
            onClick={onSkip}
            className="text-xs text-zinc-500 hover:text-zinc-300 transition-colors"
          >
            Pular tour
          </button>
          <div className="flex items-center gap-2">
            {currentStep > 0 && (
              <button
                onClick={onPrev}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-zinc-800 text-zinc-300 hover:bg-zinc-700 transition-colors"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                Anterior
              </button>
            )}
            <button
              onClick={onNext}
              className="flex items-center gap-1 px-4 py-1.5 rounded-lg text-xs font-bold text-white transition-colors"
              style={{ background: accentColor }}
            >
              {currentStep < totalSteps - 1 ? (
                <>
                  Proximo
                  <ChevronRight className="h-3.5 w-3.5" />
                </>
              ) : (
                "Concluir"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
