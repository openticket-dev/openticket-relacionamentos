/**
 * Shared UI component tests (packages/ui).
 *
 * Validates rendering, variants, and accessibility attributes
 * for core ShadCN/UI components used across all frontends.
 */

import {
  type ReactElement,
} from "react";

// Lightweight SSR render for testing without jsdom
function render(element: ReactElement): string {
  const ReactDOMServer = require('react-dom/server');
  return ReactDOMServer.renderToStaticMarkup(element);
}

// ── Button ───────────────────────────────────────────────────

import { Button } from '../button';

describe('Button', () => {
  it('deve renderizar com texto', () => {
    const html = render(<Button>Comprar Ingresso</Button>);
    expect(html).toContain('Comprar Ingresso');
    expect(html).toContain('button');
  });

  it('deve aplicar variante destructive', () => {
    const html = render(<Button variant="destructive">Cancelar</Button>);
    expect(html).toContain('destructive');
  });

  it('deve aplicar tamanho sm', () => {
    const html = render(<Button size="sm">Pequeno</Button>);
    expect(html).toContain('h-8');
  });

  it('deve renderizar como disabled', () => {
    const html = render(<Button disabled>Desabilitado</Button>);
    expect(html).toContain('disabled');
  });
});

// ── Card ─────────────────────────────────────────────────────

import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../card';

describe('Card', () => {
  it('deve renderizar estrutura completa', () => {
    const html = render(
      <Card>
        <CardHeader>
          <CardTitle>Evento</CardTitle>
          <CardDescription>Descricao do evento</CardDescription>
        </CardHeader>
        <CardContent>Conteudo</CardContent>
        <CardFooter>Rodape</CardFooter>
      </Card>,
    );
    expect(html).toContain('Evento');
    expect(html).toContain('Descricao do evento');
    expect(html).toContain('Conteudo');
    expect(html).toContain('Rodape');
  });

  it('deve aplicar classes de estilo', () => {
    const html = render(<Card className="custom-class">Test</Card>);
    expect(html).toContain('custom-class');
    expect(html).toContain('rounded-lg');
  });
});

// ── Badge ────────────────────────────────────────────────────

import { Badge } from '../badge';

describe('Badge', () => {
  it('deve renderizar com variante default', () => {
    const html = render(<Badge>Ativo</Badge>);
    expect(html).toContain('Ativo');
    expect(html).toContain('rounded-full');
  });

  it('deve aplicar variante secondary', () => {
    const html = render(<Badge variant="secondary">Pendente</Badge>);
    expect(html).toContain('secondary');
  });

  it('deve aplicar variante destructive', () => {
    const html = render(<Badge variant="destructive">Cancelado</Badge>);
    expect(html).toContain('destructive');
  });

  it('deve aplicar variante outline', () => {
    const html = render(<Badge variant="outline">Rascunho</Badge>);
    expect(html).toContain('Rascunho');
  });
});

// ── Input ────────────────────────────────────────────────────

import { Input } from '../input';

describe('Input', () => {
  it('deve renderizar input text', () => {
    const html = render(<Input type="text" placeholder="Nome completo" />);
    expect(html).toContain('input');
    expect(html).toContain('Nome completo');
  });

  it('deve renderizar input email', () => {
    const html = render(<Input type="email" placeholder="Email" />);
    expect(html).toContain('type="email"');
  });

  it('deve aplicar classe customizada', () => {
    const html = render(<Input className="w-64" />);
    expect(html).toContain('w-64');
  });

  it('deve renderizar como disabled', () => {
    const html = render(<Input disabled />);
    expect(html).toContain('disabled');
  });
});

// ── Dialog (static parts) ────────────────────────────────────

import { DialogHeader, DialogFooter } from '../dialog';

describe('Dialog static parts', () => {
  it('deve renderizar DialogHeader', () => {
    const html = render(<DialogHeader>Titulo</DialogHeader>);
    expect(html).toContain('Titulo');
    expect(html).toContain('flex');
  });

  it('deve renderizar DialogFooter', () => {
    const html = render(
      <DialogFooter>
        <Button>Confirmar</Button>
      </DialogFooter>,
    );
    expect(html).toContain('Confirmar');
  });
});
