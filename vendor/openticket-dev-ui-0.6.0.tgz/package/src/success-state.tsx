import * as React from 'react';
import { Button } from './button';
import { Card, CardContent } from './card';
import { CheckCircle } from 'lucide-react';

interface SuccessStateProps {
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}

const SuccessState = ({ title, message, actionLabel, onAction }: SuccessStateProps) => {
  return (
    <Card className="w-full border-2 border-dashed border-green-200 bg-green-50 dark:bg-green-900/10">
      <CardContent className="flex flex-col items-center justify-center p-10 text-center">
        <div className="mb-4 rounded-full border border-dashed border-green-300 bg-white p-4 dark:bg-green-900/20">
          <CheckCircle className="h-12 w-12 text-green-500" />
        </div>
        <h3 className="text-xl font-semibold text-green-800 dark:text-green-300">{title}</h3>
        <p className="mt-2 text-sm text-green-700 dark:text-green-400">{message}</p>
        {actionLabel && onAction && (
          <Button onClick={onAction} className="mt-6 bg-green-600 hover:bg-green-700">
            {actionLabel}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default SuccessState;