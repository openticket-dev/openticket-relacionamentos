/**
 * Theme tokens por vertical — extraído dos `_legacy/` Vite.
 * Cada vertical tem accent próprio + tokens dark/light.
 *
 * Uso: `const t = getVerticalThemeTokens('gastronomia', isDark);`
 *
 * NOTA: `admin/theme.ts` já exporta `getThemeTokens(isDark)` cross-vertical
 * (single accent purple). Esta função é o passo seguinte: tokens por vertical
 * com accent próprio (rose/amber/emerald/etc) pra port das pages _legacy/.
 */

import type { Vertical } from "./SidebarSwitcher/types";

// Re-export pra facilitar consumo + tipo extra pras 2 verticais que não estão no SidebarSwitcher.
export type LegacyVertical = Vertical | "healthcare" | "relacionamentos";

export type VerticalThemeTokens = {
  bg: string;
  sidebarBg: string;
  sidebarBorder: string;
  sidebarText: string;
  sidebarActiveText: string;
  sidebarActiveBg: string;
  sidebarActiveBorder: string;
  sidebarHoverBg: string;
  headerBg: string;
  headerBorder: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  divider: string;
  toggleBg: string;
  accent: string;
  accentLight: string;
  accentBg: string;
  cardBg: string;
  cardBorder: string;
};

type Palette = {
  accentDark: string;
  accentLightDark: string;
  accentDarkRgba: string; // for "rgba(R,G,B,...)" backgrounds, NO alpha
  accentLight: string;
  accentLightLight: string;
  accentLightRgba: string;
  borderLight: string; // hex used for sidebar borders in light mode
  cardBgLight: string;
  bgLight: string;
};

// Cores extraídas dos sidebars _legacy/ de cada vertical.
const PALETTES: Record<LegacyVertical, Palette> = {
  eventos: {
    accentDark: "#a855f7",
    accentLightDark: "#c4b5fd",
    accentDarkRgba: "168,85,247",
    accentLight: "#9333ea",
    accentLightLight: "#a78bfa",
    accentLightRgba: "147,51,234",
    borderLight: "#e9d5ff",
    cardBgLight: "#ffffff",
    bgLight: "#fafaf9",
  },
  gastronomia: {
    accentDark: "#f59e0b",
    accentLightDark: "#fbbf24",
    accentDarkRgba: "245,158,11",
    accentLight: "#d97706",
    accentLightLight: "#fbbf24",
    accentLightRgba: "217,119,6",
    borderLight: "#fed7aa",
    cardBgLight: "#ffffff",
    bgLight: "#fefcfb",
  },
  cultura: {
    accentDark: "#f43f5e",
    accentLightDark: "#fda4af",
    accentDarkRgba: "244,63,94",
    accentLight: "#e11d48",
    accentLightLight: "#fb7185",
    accentLightRgba: "225,29,72",
    borderLight: "#fce7f3",
    cardBgLight: "#ffffff",
    bgLight: "#fefcfb",
  },
  esportes: {
    accentDark: "#10b981",
    accentLightDark: "#6ee7b7",
    accentDarkRgba: "16,185,129",
    accentLight: "#059669",
    accentLightLight: "#34d399",
    accentLightRgba: "5,150,105",
    borderLight: "#d1fae5",
    cardBgLight: "#ffffff",
    bgLight: "#f0fdf4",
  },
  igreja: {
    accentDark: "#f59e0b",
    accentLightDark: "#fcd34d",
    accentDarkRgba: "245,158,11",
    accentLight: "#d97706",
    accentLightLight: "#fbbf24",
    accentLightRgba: "217,119,6",
    borderLight: "#fef3c7",
    cardBgLight: "#ffffff",
    bgLight: "#fffbeb",
  },
  varejo: {
    accentDark: "#3b82f6",
    accentLightDark: "#93c5fd",
    accentDarkRgba: "59,130,246",
    accentLight: "#2563eb",
    accentLightLight: "#60a5fa",
    accentLightRgba: "37,99,235",
    borderLight: "#dbeafe",
    cardBgLight: "#ffffff",
    bgLight: "#f8fafc",
  },
  educacao: {
    accentDark: "#818cf8",
    accentLightDark: "#a5b4fc",
    accentDarkRgba: "129,140,248",
    accentLight: "#4f46e5",
    accentLightLight: "#818cf8",
    accentLightRgba: "79,70,229",
    borderLight: "#e0e7ff",
    cardBgLight: "#ffffff",
    bgLight: "#f8fafc",
  },
  healthcare: {
    accentDark: "#06b6d4",
    accentLightDark: "#67e8f9",
    accentDarkRgba: "6,182,212",
    accentLight: "#0891b2",
    accentLightLight: "#22d3ee",
    accentLightRgba: "8,145,178",
    borderLight: "#cffafe",
    cardBgLight: "#ffffff",
    bgLight: "#ecfeff",
  },
  relacionamentos: {
    accentDark: "#ec4899",
    accentLightDark: "#f9a8d4",
    accentDarkRgba: "236,72,153",
    accentLight: "#db2777",
    accentLightLight: "#f472b6",
    accentLightRgba: "219,39,119",
    borderLight: "#fce7f3",
    cardBgLight: "#ffffff",
    bgLight: "#fdf2f8",
  },
};

export function getVerticalThemeTokens(vertical: LegacyVertical, isDark: boolean): VerticalThemeTokens {
  const p = PALETTES[vertical];
  // Dark neutrals follow the Brand Book §3 cosmic palette (bg #07060d, card
  // #13101f, line #2a2342, txt #ece9f5). Per-vertical accents (p.*) are the
  // CEO-locked vertical colors — left untouched. Only neutrals carry the rebrand.
  return isDark
    ? {
        bg: "#07060d", // app bg canonical
        sidebarBg: "#0d0a18", // bg tier 2
        sidebarBorder: "#2a2342", // line
        sidebarText: "#9a93b5", // muted
        sidebarActiveText: p.accentLightDark,
        sidebarActiveBg: `rgba(${p.accentDarkRgba},0.15)`,
        sidebarActiveBorder: `rgba(${p.accentDarkRgba},0.2)`,
        sidebarHoverBg: "rgba(255,255,255,0.04)",
        headerBg: "rgba(7,6,13,0.8)", // #07060d
        headerBorder: "rgba(42,35,66,0.6)", // line
        text: "#ece9f5", // txt primary (not pure white)
        textSecondary: "#9a93b5",
        textMuted: "#6f6790", // mut2
        divider: "#2a2342",
        toggleBg: "rgba(255,255,255,0.06)",
        accent: p.accentDark,
        accentLight: p.accentLightDark,
        accentBg: `rgba(${p.accentDarkRgba},0.1)`,
        cardBg: "#13101f", // card surface
        cardBorder: "#2a2342",
      }
    : {
        bg: p.bgLight,
        sidebarBg: "#ffffff",
        sidebarBorder: p.borderLight,
        sidebarText: "#57534e",
        sidebarActiveText: p.accentLight,
        sidebarActiveBg: `rgba(${p.accentLightRgba},0.08)`,
        sidebarActiveBorder: `rgba(${p.accentLightRgba},0.15)`,
        sidebarHoverBg: "rgba(0,0,0,0.04)",
        headerBg: `rgba(${p.bgLight === "#ffffff" ? "255,255,255" : "254,252,251"},0.8)`,
        headerBorder: "rgba(0,0,0,0.06)",
        text: "#1c1917",
        textSecondary: "#57534e",
        textMuted: "#78716c",
        divider: p.borderLight,
        toggleBg: "rgba(0,0,0,0.05)",
        accent: p.accentLight,
        accentLight: p.accentLightLight,
        accentBg: `rgba(${p.accentLightRgba},0.06)`,
        cardBg: p.cardBgLight,
        cardBorder: p.borderLight,
      };
}

export const VERTICAL_PALETTES = PALETTES;
