import type { Meta, StoryObj } from '@storybook/react';
import { Input } from './input';
import { Label } from './label';

/**
 * Input — campo base de formulario (busca, login, checkout).
 *
 * A11y: SEMPRE associar com Label (htmlFor + id).
 */
const meta: Meta<typeof Input> = {
  title: 'Forms/Input',
  component: Input,
  tags: ['autodocs'],
  parameters: { a11y: { disable: false } },
};

export default meta;
type Story = StoryObj<typeof Input>;

export const ComLabel: Story = {
  render: () => (
    <div className="grid w-[320px] gap-1.5">
      <Label htmlFor="email">Email</Label>
      <Input id="email" type="email" placeholder="voce@exemplo.com" />
    </div>
  ),
};

export const Senha: Story = {
  render: () => (
    <div className="grid w-[320px] gap-1.5">
      <Label htmlFor="password">Senha</Label>
      <Input id="password" type="password" placeholder="********" />
    </div>
  ),
};

export const Disabled: Story = {
  render: () => (
    <div className="grid w-[320px] gap-1.5">
      <Label htmlFor="cpf">CPF (bloqueado)</Label>
      <Input id="cpf" disabled value="123.456.789-00" />
    </div>
  ),
};
