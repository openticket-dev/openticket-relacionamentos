import type { Meta, StoryObj } from '@storybook/react';
import { Ticket } from 'lucide-react';
import EmptyState from './empty-state';

/**
 * EmptyState — usado quando uma listagem nao tem itens (eventos, ingressos, parceiros).
 *
 * Zero-mock: o icone e os textos vem de props, nunca hardcoded no componente final.
 */
const meta: Meta<typeof EmptyState> = {
  title: 'States/EmptyState',
  component: EmptyState,
  tags: ['autodocs'],
  parameters: { a11y: { disable: false } },
};

export default meta;
type Story = StoryObj<typeof EmptyState>;

export const SemEventos: Story = {
  args: {
    icon: Ticket,
    title: 'Nenhum evento por aqui',
    description: 'Quando criar seu primeiro evento, ele aparece nessa lista.',
    actionLabel: 'Criar evento',
    onAction: () => {
      /* intencionalmente vazio — handler real vem do consumidor */
    },
  },
};

export const SemAcao: Story = {
  args: {
    icon: Ticket,
    title: 'Nenhum ingresso disponivel',
    description: 'Volte mais tarde para verificar novos lotes.',
  },
};
