import type { Meta, StoryObj } from '@storybook/react';
import SuccessState from './success-state';

/**
 * SuccessState — confirma sucesso pos-acao (ingresso comprado, evento publicado).
 */
const meta: Meta<typeof SuccessState> = {
  title: 'States/SuccessState',
  component: SuccessState,
  tags: ['autodocs'],
  parameters: { a11y: { disable: false } },
};

export default meta;
type Story = StoryObj<typeof SuccessState>;

export const IngressoComprado: Story = {
  args: {
    title: 'Compra confirmada!',
    message: 'Voce vai receber o ingresso por email em alguns minutos.',
    actionLabel: 'Ver meus ingressos',
    onAction: () => {
      /* handler real vem do consumidor */
    },
  },
};

export const SemAcao: Story = {
  args: {
    title: 'Evento publicado',
    message: 'Seu evento ja esta visivel para o publico.',
  },
};
