import * as React from "react";
import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "./card";

type Props = {
  icon: LucideIcon;
  title: string;
  description: string;
  /**
   * Subgraph/serviço backend que precisa estar conectado pra esta feature.
   * Ex: "api-church", "api-gastronomy".
   */
  blockedBy?: string;
  /** Texto extra opcional abaixo do badge. */
  helper?: string;
  /** Cor do gradient + acento (default: amber). Ex: "#f59e0b". */
  accentColor?: string;
  /** Cor secundária do gradient (default: orange). Ex: "#f97316". */
  accentColorSecondary?: string;
};

/**
 * Coming-soon placeholder pra páginas admin que ainda não tem backend
 * conectado. Reusa em qualquer vertical passando `accentColor`.
 *
 * Substitui o template `EmBreve` legado de openticket-igreja (11 stubs).
 */
export function ComingSoon({
  icon: Icon,
  title,
  description,
  blockedBy,
  helper,
  accentColor = "#f59e0b",
  accentColorSecondary = "#f97316",
}: Props) {
  const accentRgba = (alpha: number) => {
    const rgb = hexToRgb(accentColor);
    return `rgba(${rgb}, ${alpha})`;
  };
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center"
          style={{
            background: `linear-gradient(135deg, ${accentColor}, ${accentColorSecondary})`,
            boxShadow: `0 8px 24px ${accentRgba(0.3)}`,
          }}
        >
          <Icon className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-black tracking-tight">{title}</h1>
          <p className="text-muted-foreground mt-0.5 text-sm">{description}</p>
        </div>
      </div>
      <Card style={{ borderColor: accentRgba(0.2) }}>
        <CardContent className="p-10 text-center">
          <div
            className="inline-flex p-4 rounded-2xl mb-4"
            style={{ background: accentRgba(0.1) }}
          >
            <Icon className="h-10 w-10" style={{ color: accentColor }} />
          </div>
          <h2 className="text-lg font-bold mb-2">Em breve</h2>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            Gestão de <strong>{title.toLowerCase()}</strong> será disponibilizada
            {blockedBy ? (
              <>
                {" "}
                quando o subgraph
                <code
                  className="mx-1 px-1.5 py-0.5 rounded font-mono text-[11px]"
                  style={{ background: accentRgba(0.1), color: accentColor }}
                >
                  {blockedBy}
                </code>
                estiver conectado.
              </>
            ) : (
              " em breve."
            )}
          </p>
          {helper && (
            <p className="text-xs text-muted-foreground/60 mt-3">{helper}</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function hexToRgb(hex: string): string {
  const clean = hex.replace("#", "");
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);
  return `${r}, ${g}, ${b}`;
}
