import type { Meta, StoryObj } from '@storybook/react';
import { OpenTicketLogo } from './open-ticket-logo';

/**
 * OpenTicketLogo — marca grafica usada em headers, splash screens e PDFs de ingresso.
 */
const meta: Meta<typeof OpenTicketLogo> = {
  title: 'Brand/OpenTicketLogo',
  component: OpenTicketLogo,
  tags: ['autodocs'],
  parameters: { a11y: { disable: false } },
};

export default meta;
type Story = StoryObj<typeof OpenTicketLogo>;

export const Padrao: Story = {};

export const Grande: Story = {
  args: { className: 'h-32 w-32 text-orange-500' },
};
