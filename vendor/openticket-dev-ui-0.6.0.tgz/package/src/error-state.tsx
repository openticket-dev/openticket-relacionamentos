import * as React from 'react';
import { Button } from './button';
import { Card, CardContent } from './card';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ErrorStateProps {
  title?: string;
  message?: string;
  onRetry?: () => void;
}

const ErrorState = ({
  title = "Ocorreu um Erro",
  message = "Não foi possível carregar os dados. Por favor, tente novamente.",
  onRetry,
}: ErrorStateProps) => {
  return (
    <Card className="w-full border-2 border-dashed border-red-200 bg-red-50 dark:bg-red-900/10">
      <CardContent className="flex flex-col items-center justify-center p-10 text-center">
        <div className="mb-4 rounded-full border border-dashed border-red-300 bg-white p-4 dark:bg-red-900/20">
          <AlertTriangle className="h-12 w-12 text-red-500" />
        </div>
        <h3 className="text-xl font-semibold text-red-700 dark:text-red-300">{title}</h3>
        <p className="mt-2 text-sm text-red-600 dark:text-red-400">{message}</p>
        {onRetry && (
          <Button onClick={onRetry} variant="destructive" className="mt-6">
            <RefreshCw className="mr-2 h-4 w-4" /> Tentar Novamente
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default ErrorState;