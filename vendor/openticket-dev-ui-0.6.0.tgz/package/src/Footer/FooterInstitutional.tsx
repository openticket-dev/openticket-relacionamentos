import * as React from 'react';
import { FooterBase } from './FooterBase';
import type { FooterColumn, VerticalAccent } from './types';

/**
 * FooterInstitutional — main footer for openticket.com.br.
 *
 * Six columns matching the masterplan Sprint 7.1:
 *   Brand | Descubra | Seja cliente | Para produtores | Comunidade | Suporte
 *
 * Brand column is rendered by FooterBase, so we pass 5 link columns here.
 */

const accent: VerticalAccent = {
  primary: '#0EA5E9',
  emoji: '🎟️',
  gradient: 'linear-gradient(90deg, #0EA5E9 0%, #6366F1 50%, #A855F7 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descubra',
    audience: 'all',
    links: [
      { label: 'Festas', href: '/eventos' },
      { label: 'Shows', href: '/eventos/shows' },
      { label: 'Esportes', href: '/esportes' },
      { label: 'Gastronomia', href: '/gastronomia' },
      { label: 'Cultura', href: '/cultura' },
      { label: 'Igrejas', href: '/igreja' },
      { label: 'Educação', href: '/educacao' },
      { label: 'Varejo', href: '/varejo' },
    ],
  },
  {
    title: 'Seja cliente',
    audience: 'all',
    links: [
      { label: 'Como funciona', href: '/como-funciona' },
      { label: 'Crie seu negócio', href: '/criar-conta' },
      { label: 'Casos de sucesso', href: '/casos-de-sucesso' },
      { label: 'Preços', href: '/precos' },
      { label: 'Agende demo', href: '/demo' },
    ],
  },
  {
    title: 'Para produtores',
    audience: 'all',
    links: [
      { label: 'Dashboard admin', href: '/admin' },
      { label: 'Marketing Suite', href: '/marketing-suite' },
      { label: 'Antifraud', href: '/antifraud' },
      { label: 'Cashless', href: '/cashless' },
      { label: 'API', href: '/docs/api' },
      { label: 'Sponsor portal', href: '/sponsors' },
    ],
  },
  {
    title: 'Comunidade',
    audience: 'all',
    links: [
      { label: 'Blog', href: '/blog' },
      { label: 'Tutoriais', href: '/tutoriais' },
      { label: 'Eventos OT', href: '/eventos-ot' },
      { label: 'Discord', href: 'https://discord.gg/openticket', external: true },
      { label: 'Status do sistema', href: 'https://status.openticket.com.br', external: true },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'Contato', href: '/contato' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
      { label: 'LGPD', href: '/lgpd' },
      { label: 'Imprensa', href: '/imprensa' },
    ],
  },
];

export interface FooterInstitutionalProps {
  className?: string;
}

export function FooterInstitutional({ className }: FooterInstitutionalProps) {
  return (
    <FooterBase
      vertical="institutional"
      accent={accent}
      brand={{
        tagline: '7 verticais em 1 — a plataforma de ticketing camaleão.',
        complianceBadges: ['LGPD', 'PCI-DSS', 'ISO 27001'],
      }}
      columns={columns}
      role="anonymous"
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket. Todos os direitos reservados.`,
      }}
      className={className}
    />
  );
}
