import * as React from 'react';
import { cn } from '../lib/utils';
import { OpenTicketLogo } from '../open-ticket-logo';
import type { FooterBaseProps, FooterColumn, UserRole } from './types';

/**
 * FooterBase — chameleon shell shared by every vertical footer.
 *
 * Receives:
 *   - accent (color/emoji/gradient per vertical)
 *   - brand (tagline + compliance badges)
 *   - columns (already filtered for the role outside, OR filtered here via `role`)
 *   - switcher (cross-vertical mini links)
 *   - legal (copyright + CNPJ)
 *
 * Renders nothing vertical-specific — verticals are composed via wrappers
 * (FooterEventos, FooterGastronomia, etc.) that pass the right props.
 */
export function FooterBase({
  vertical,
  accent,
  brand,
  columns,
  role = 'anonymous',
  switcher,
  legal,
  hero3DAware = false,
  className,
}: FooterBaseProps) {
  const visibleColumns = filterColumnsByRole(columns, role);

  return (
    <footer
      data-vertical={vertical}
      data-role={role}
      className={cn(
        'relative w-full border-t border-border/40 bg-background text-foreground',
        className,
      )}
    >
      {/* Top accent line — single source of vertical color */}
      <div
        aria-hidden
        className={cn(
          'h-[2px] w-full',
          hero3DAware && 'shadow-[0_0_24px_rgba(0,0,0,0.35)]',
        )}
        style={{
          background: accent.gradient ?? accent.primary,
        }}
      />

      <div className="mx-auto w-full max-w-7xl px-6 py-12 lg:py-16">
        {/* Brand row + columns grid */}
        <div className="grid gap-10 lg:grid-cols-12">
          {/* Brand column */}
          <div className="lg:col-span-3">
            <div className="flex items-center gap-2">
              <OpenTicketLogo className="h-8 w-8" />
              <span className="text-lg font-semibold tracking-tight">
                OpenTicket
              </span>
            </div>
            {brand.tagline ? (
              <p className="mt-3 max-w-xs text-sm text-muted-foreground">
                {brand.tagline}
              </p>
            ) : null}

            {brand.complianceBadges && brand.complianceBadges.length > 0 ? (
              <ul className="mt-6 flex flex-wrap gap-2">
                {brand.complianceBadges.map((badge) => (
                  <li
                    key={badge}
                    className="rounded-full border border-border/60 px-2.5 py-1 text-[11px] font-medium uppercase tracking-wide text-muted-foreground"
                  >
                    {badge}
                  </li>
                ))}
              </ul>
            ) : null}
          </div>

          {/* Link columns */}
          <div
            className={cn(
              'grid gap-8 lg:col-span-9',
              gridColsClass(visibleColumns.length),
            )}
          >
            {visibleColumns.map((col) => (
              <FooterColumnView
                key={col.title}
                column={col}
                accentColor={accent.primary}
              />
            ))}
          </div>
        </div>

        {/* Cross-vertical switcher */}
        {switcher && switcher.length > 0 ? (
          <div className="mt-10 flex flex-wrap items-center gap-3 border-t border-border/30 pt-6">
            <span className="text-xs uppercase tracking-wide text-muted-foreground">
              Outras verticais
            </span>
            <ul className="flex flex-wrap gap-2">
              {switcher.map((s) => (
                <li key={s.href}>
                  <a
                    href={s.href}
                    className="inline-flex items-center gap-1.5 rounded-md border border-border/60 px-2.5 py-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {s.emoji ? <span aria-hidden>{s.emoji}</span> : null}
                    <span>{s.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        {/* Legal bottom bar */}
        {legal ? (
          <div className="mt-10 flex flex-col gap-2 border-t border-border/30 pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
            <p>{legal.copyright}</p>
            {legal.cnpj ? <p>CNPJ {legal.cnpj}</p> : null}
          </div>
        ) : null}
      </div>
    </footer>
  );
}

function FooterColumnView({
  column,
  accentColor,
}: {
  column: FooterColumn;
  accentColor: string;
}) {
  return (
    <div>
      <h3
        className="mb-4 text-sm font-semibold uppercase tracking-wide"
        style={{ color: accentColor }}
      >
        {column.title}
      </h3>
      <ul className="space-y-2.5">
        {column.links.map((link) => (
          <li key={link.href}>
            <a
              href={link.href}
              target={link.external ? '_blank' : undefined}
              rel={link.external ? 'noreferrer noopener' : undefined}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

function filterColumnsByRole(
  columns: FooterColumn[],
  role: UserRole,
): FooterColumn[] {
  return columns.filter((c) => {
    if (!c.audience || c.audience === 'all') return true;
    if (role === 'dual') return true;
    if (role === 'anonymous') return c.audience === 'consumer';
    return c.audience === role;
  });
}

function gridColsClass(count: number): string {
  switch (count) {
    case 1:
      return 'grid-cols-1';
    case 2:
      return 'grid-cols-1 sm:grid-cols-2';
    case 3:
      return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3';
    case 4:
      return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4';
    case 5:
      return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-5';
    case 6:
    default:
      return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6';
  }
}
