// Footer System — Wave 7 — Shared types
// Chameleon footer pattern: same shell, different verticals.

export type VerticalId =
  | 'institutional'
  | 'eventos'
  | 'gastronomia'
  | 'esportes'
  | 'varejo'
  | 'cultura'
  | 'igreja'
  | 'educacao'
  | 'healthcare'
  | 'relacionamentos';

export type UserRole = 'anonymous' | 'consumer' | 'gestor' | 'dual';

export interface FooterLink {
  label: string;
  href: string;
  external?: boolean;
}

export interface FooterColumn {
  /** Column heading (e.g. "Descobrir", "Sua conta", "Gerenciar", "Suporte") */
  title: string;
  /** Optional audience tag — used by dual-context logic to pick which columns to render */
  audience?: 'all' | 'consumer' | 'gestor';
  links: FooterLink[];
}

export interface VerticalAccent {
  /** Hex color used for headings, hovers and the top accent line. */
  primary: string;
  /** Optional secondary color — gradients/badges. */
  secondary?: string;
  /** Optional emoji used by mini-switchers. */
  emoji?: string;
  /** Optional CSS gradient string for hero/accent surfaces. */
  gradient?: string;
}

export interface FooterBrand {
  /** Tagline shown below the logo (e.g. "7 verticais em 1"). */
  tagline?: string;
  /** Compliance badges row (LGPD/PCI-DSS/ISO etc.). */
  complianceBadges?: string[];
}

export interface FooterBaseProps {
  vertical: VerticalId;
  accent: VerticalAccent;
  brand: FooterBrand;
  columns: FooterColumn[];
  /** Current viewer role — drives which columns appear. */
  role?: UserRole;
  /** Cross-vertical mini switcher — list of icons/links to other verticals. */
  switcher?: { label: string; href: string; emoji?: string }[];
  /** Bottom bar copy (copyright/CNPJ). */
  legal?: { copyright: string; cnpj?: string };
  /** When true, renders a 3D-aware top accent (e.g. hero-aware glow). */
  hero3DAware?: boolean;
  className?: string;
}
