'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterIgreja — vertical indigo (#4f46e5).
 *
 * Cobre cultos, retiros, conferencias e dizimo — pastor, lider, membro, visitante.
 */

const accent: VerticalAccent = {
  primary: '#4f46e5',
  emoji: '⛪',
  gradient: 'linear-gradient(90deg, #312e81 0%, #4f46e5 50%, #818cf8 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Cultos', href: '/igreja/cultos' },
      { label: 'Conferências', href: '/igreja/conferencias' },
      { label: 'Retiros', href: '/igreja/retiros' },
      { label: 'Células', href: '/igreja/celulas' },
      { label: 'Cursos', href: '/igreja/cursos' },
      { label: 'Missões', href: '/igreja/missoes' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Inscrições', href: '/conta/inscricoes' },
      { label: 'Dízimo & Ofertas', href: '/conta/dizimo' },
      { label: 'Comprovantes', href: '/conta/comprovantes' },
      { label: 'Família', href: '/conta/familia' },
      { label: 'Discipulado', href: '/conta/discipulado' },
      { label: 'Pedidos de oração', href: '/conta/oracao' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Membros', href: '/admin/membros' },
      { label: 'Células', href: '/admin/celulas' },
      { label: 'Eventos', href: '/admin/eventos' },
      { label: 'Financeiro', href: '/admin/financeiro' },
      { label: 'Discipulado', href: '/admin/discipulado' },
      { label: 'Comunicação', href: '/admin/comunicacao' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterIgrejaProps {
  role?: UserRole;
  className?: string;
}

export function FooterIgreja({ role, className }: FooterIgrejaProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'igreja');

  return (
    <FooterBase
      vertical="igreja"
      accent={accent}
      brand={{
        tagline: 'Do culto ao discipulado — comunidade que se conecta.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Igreja.`,
      }}
      className={className}
    />
  );
}
