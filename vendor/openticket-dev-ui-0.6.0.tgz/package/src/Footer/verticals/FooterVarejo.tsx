'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterVarejo — vertical ambar (#d97706).
 *
 * Cobre lojas, e-commerce, pop-ups e outlets — lojista, comprador, marca, fornecedor.
 */

const accent: VerticalAccent = {
  primary: '#d97706',
  emoji: '🛒',
  gradient: 'linear-gradient(90deg, #92400e 0%, #d97706 50%, #fbbf24 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Lojas', href: '/varejo/lojas' },
      { label: 'Marcas', href: '/varejo/marcas' },
      { label: 'Pop-ups', href: '/varejo/popups' },
      { label: 'Outlets', href: '/varejo/outlets' },
      { label: 'Lançamentos', href: '/varejo/lancamentos' },
      { label: 'Marketplace', href: '/varejo/marketplace' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Pedidos', href: '/conta/pedidos' },
      { label: 'Vouchers', href: '/conta/vouchers' },
      { label: 'Cashback', href: '/conta/cashback' },
      { label: 'Lista de desejos', href: '/conta/desejos' },
      { label: 'Endereços', href: '/conta/enderecos' },
      { label: 'Devoluções', href: '/conta/devolucoes' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Catálogo', href: '/admin/catalogo' },
      { label: 'Estoque', href: '/admin/estoque' },
      { label: 'Pedidos', href: '/admin/pedidos' },
      { label: 'Promoções', href: '/admin/promocoes' },
      { label: 'Logística', href: '/admin/logistica' },
      { label: 'Fiscal', href: '/admin/fiscal' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterVarejoProps {
  role?: UserRole;
  className?: string;
}

export function FooterVarejo({ role, className }: FooterVarejoProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'varejo');

  return (
    <FooterBase
      vertical="varejo"
      accent={accent}
      brand={{
        tagline: 'Da loja ao checkout — varejo omnichannel sem fricção.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Varejo.`,
      }}
      className={className}
    />
  );
}
