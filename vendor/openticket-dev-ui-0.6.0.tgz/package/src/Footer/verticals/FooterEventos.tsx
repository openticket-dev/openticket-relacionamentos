'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterEventos — vertical roxo (#a855f7).
 *
 * Hero3D-aware: top accent renders with a stronger glow so it sits well
 * under the WebGPU hero canvas used on the eventos hub.
 */

const accent: VerticalAccent = {
  primary: '#a855f7',
  emoji: '🎪',
  gradient: 'linear-gradient(90deg, #6d28d9 0%, #a855f7 50%, #ec4899 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Próximos eventos', href: '/eventos/proximos' },
      { label: 'Festivais', href: '/eventos/festivais' },
      { label: 'Shows', href: '/eventos/shows' },
      { label: 'Artistas', href: '/eventos/artistas' },
      { label: 'Promoters', href: '/eventos/promoters' },
      { label: 'Revenda', href: '/eventos/revenda' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Meus ingressos', href: '/conta/ingressos' },
      { label: 'QR code', href: '/conta/qr' },
      { label: 'Transferir', href: '/conta/transferir' },
      { label: 'Upgrade de setor', href: '/conta/upgrade' },
      { label: 'Histórico', href: '/conta/historico' },
      { label: 'Check-ins', href: '/conta/check-ins' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Criar evento', href: '/admin/eventos/novo' },
      { label: 'Marketing Suite', href: '/admin/marketing' },
      { label: 'Antifraud', href: '/admin/antifraud' },
      { label: 'Cashless', href: '/admin/cashless' },
      { label: 'Sponsors', href: '/admin/sponsors' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterEventosProps {
  /** Override the role for the footer (e.g. SSR with known auth). */
  role?: UserRole;
  className?: string;
}

export function FooterEventos({ role, className }: FooterEventosProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'eventos');

  return (
    <FooterBase
      vertical="eventos"
      accent={accent}
      brand={{
        tagline: 'Eventos sem fricção — do festival ao show solo.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Eventos.`,
      }}
      hero3DAware
      className={className}
    />
  );
}
