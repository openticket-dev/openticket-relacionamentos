'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterGastronomia — vertical laranja (#f97316).
 */

const accent: VerticalAccent = {
  primary: '#f97316',
  emoji: '🍔',
  gradient: 'linear-gradient(90deg, #c2410c 0%, #f97316 50%, #fbbf24 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Restaurantes', href: '/gastronomia/restaurantes' },
      { label: 'Chefs', href: '/gastronomia/chefs' },
      { label: 'Menu do dia', href: '/gastronomia/menu-do-dia' },
      { label: 'Degustações', href: '/gastronomia/degustacoes' },
      { label: 'Delivery', href: '/gastronomia/delivery' },
      { label: 'Reservas', href: '/gastronomia/reservas' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Reservas', href: '/conta/reservas' },
      { label: 'Pedidos', href: '/conta/pedidos' },
      { label: 'Mesas salvas', href: '/conta/mesas' },
      { label: 'Dividir conta', href: '/conta/dividir' },
      { label: 'Preferências', href: '/conta/preferencias' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Menu digital', href: '/admin/menu' },
      { label: 'KDS', href: '/admin/kds' },
      { label: 'Estoque', href: '/admin/estoque' },
      { label: 'Receitas', href: '/admin/receitas' },
      { label: 'Delivery', href: '/admin/delivery' },
      { label: 'Reservas', href: '/admin/reservas' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterGastronomiaProps {
  role?: UserRole;
  className?: string;
}

export function FooterGastronomia({ role, className }: FooterGastronomiaProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'gastronomia');

  return (
    <FooterBase
      vertical="gastronomia"
      accent={accent}
      brand={{
        tagline: 'Da reserva ao pós-pagamento — gastronomia inteira em um app.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Gastronomia.`,
      }}
      className={className}
    />
  );
}
