'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterRelacionamentos — vertical magenta (#d946ef).
 *
 * Cobre matchmaking, paqueras, comunidades, networking pessoal, alma-gemea,
 * eventos sociais — de speed-dating a relacionamentos serios.
 */

const accent: VerticalAccent = {
  primary: '#d946ef',
  emoji: '💞',
  gradient: 'linear-gradient(90deg, #86198f 0%, #d946ef 50%, #f0abfc 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Encontre',
    audience: 'consumer',
    links: [
      { label: 'Alma gêmea', href: '/relacionamentos/alma-gemea' },
      { label: 'Paqueras', href: '/relacionamentos/paqueras' },
      { label: 'Amizade', href: '/relacionamentos/amizade' },
      { label: 'Networking pessoal', href: '/relacionamentos/networking-pessoal' },
      { label: 'Speed dating', href: '/relacionamentos/speed-dating' },
      { label: 'Match por evento', href: '/relacionamentos/match-evento' },
    ],
  },
  {
    title: 'Comunidade',
    audience: 'consumer',
    links: [
      { label: 'Comunidades nicho', href: '/relacionamentos/comunidades-niche' },
      { label: 'LGBTQ+ friendly', href: '/relacionamentos/lgbtq-friendly' },
      { label: 'Match curso', href: '/relacionamentos/match-curso' },
      { label: 'Match igreja', href: '/relacionamentos/match-igreja' },
      { label: 'Match co-living', href: '/relacionamentos/match-co-living' },
      { label: 'Match co-working', href: '/relacionamentos/match-co-working' },
    ],
  },
  {
    title: 'Segurança',
    audience: 'all',
    links: [
      { label: 'Verificação de identidade', href: '/relacionamentos/verificacao' },
      { label: 'Botão de pânico', href: '/relacionamentos/seguranca/panico' },
      { label: 'Bloqueio e denúncia', href: '/relacionamentos/seguranca/denuncia' },
      { label: 'Política anti-fake', href: '/relacionamentos/seguranca/anti-fake' },
      { label: 'Encontros seguros', href: '/relacionamentos/seguranca/encontros' },
      { label: 'Privacidade do perfil', href: '/relacionamentos/seguranca/privacidade' },
    ],
  },
  {
    title: 'Premium',
    audience: 'consumer',
    links: [
      { label: 'Likes ilimitados', href: '/relacionamentos/premium/likes' },
      { label: 'Boost de perfil', href: '/relacionamentos/premium/boost' },
      { label: 'Ver quem curtiu', href: '/relacionamentos/premium/curtidas' },
      { label: 'Modo invisível', href: '/relacionamentos/premium/invisivel' },
      { label: 'Filtros avançados', href: '/relacionamentos/premium/filtros' },
      { label: 'Assinatura anual', href: '/relacionamentos/premium/anual' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Reportar usuário', href: '/relacionamentos/reportar' },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
      { label: 'Cookies', href: '/cookies' },
    ],
  },
  {
    title: 'Sobre',
    audience: 'all',
    links: [
      { label: 'Manifesto', href: '/relacionamentos/manifesto' },
      { label: 'Como funciona', href: '/relacionamentos/como-funciona' },
      { label: 'Histórias reais', href: '/relacionamentos/historias' },
      { label: 'Imprensa', href: '/imprensa' },
      { label: 'Carreiras', href: '/carreiras' },
      { label: 'Contato', href: '/contato' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterRelacionamentosProps {
  role?: UserRole;
  className?: string;
}

export function FooterRelacionamentos({ role, className }: FooterRelacionamentosProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'relacionamentos');

  return (
    <FooterBase
      vertical="relacionamentos"
      accent={accent}
      brand={{
        tagline: 'Conexões reais, encontros seguros — relacionamentos sem máscara.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Relacionamentos.`,
      }}
      className={className}
    />
  );
}
