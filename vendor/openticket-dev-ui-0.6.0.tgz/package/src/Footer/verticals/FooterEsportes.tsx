'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterEsportes — vertical verde (#16a34a).
 *
 * Cobre futebol, basquete, voley e ginasios — clube, federacao, atleta, torcedor.
 */

const accent: VerticalAccent = {
  primary: '#16a34a',
  emoji: '⚽',
  gradient: 'linear-gradient(90deg, #166534 0%, #16a34a 50%, #4ade80 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Próximos jogos', href: '/esportes/jogos' },
      { label: 'Times', href: '/esportes/times' },
      { label: 'Campeonatos', href: '/esportes/campeonatos' },
      { label: 'Arenas', href: '/esportes/arenas' },
      { label: 'Atletas', href: '/esportes/atletas' },
      { label: 'Sócio torcedor', href: '/esportes/socio' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Meus ingressos', href: '/conta/ingressos' },
      { label: 'Cadeira cativa', href: '/conta/cativa' },
      { label: 'Carteirinha', href: '/conta/carteirinha' },
      { label: 'Histórico', href: '/conta/historico' },
      { label: 'Transferir', href: '/conta/transferir' },
      { label: 'Check-ins', href: '/conta/check-ins' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Criar partida', href: '/admin/jogos/novo' },
      { label: 'Setores e mapa', href: '/admin/setores' },
      { label: 'Sócio torcedor', href: '/admin/socio' },
      { label: 'Antifraud', href: '/admin/antifraud' },
      { label: 'Patrocínios', href: '/admin/patrocinios' },
      { label: 'Federação', href: '/admin/federacao' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterEsportesProps {
  role?: UserRole;
  className?: string;
}

export function FooterEsportes({ role, className }: FooterEsportesProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'esportes');

  return (
    <FooterBase
      vertical="esportes"
      accent={accent}
      brand={{
        tagline: 'Do estádio ao app — esporte sem fila e sem fricção.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Esportes.`,
      }}
      hero3DAware
      className={className}
    />
  );
}
