'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterHealthcare — vertical teal (#0d9488).
 *
 * Cobre clinicas, telemedicina, exames e congressos medicos — paciente, profissional, clinica.
 */

const accent: VerticalAccent = {
  primary: '#0d9488',
  emoji: '🩺',
  gradient: 'linear-gradient(90deg, #115e59 0%, #0d9488 50%, #5eead4 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Especialidades', href: '/healthcare/especialidades' },
      { label: 'Clínicas', href: '/healthcare/clinicas' },
      { label: 'Telemedicina', href: '/healthcare/telemedicina' },
      { label: 'Exames', href: '/healthcare/exames' },
      { label: 'Congressos', href: '/healthcare/congressos' },
      { label: 'Planos', href: '/healthcare/planos' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Consultas', href: '/conta/consultas' },
      { label: 'Prontuário', href: '/conta/prontuario' },
      { label: 'Receitas', href: '/conta/receitas' },
      { label: 'Exames', href: '/conta/exames' },
      { label: 'Plano de saúde', href: '/conta/plano' },
      { label: 'Família', href: '/conta/familia' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Agenda', href: '/admin/agenda' },
      { label: 'Profissionais', href: '/admin/profissionais' },
      { label: 'Prontuários', href: '/admin/prontuarios' },
      { label: 'Convênios', href: '/admin/convenios' },
      { label: 'Faturamento', href: '/admin/faturamento' },
      { label: 'Compliance LGPD', href: '/admin/lgpd' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterHealthcareProps {
  role?: UserRole;
  className?: string;
}

export function FooterHealthcare({ role, className }: FooterHealthcareProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'healthcare');

  return (
    <FooterBase
      vertical="healthcare"
      accent={accent}
      brand={{
        tagline: 'Da consulta ao pós-atendimento — saúde sem fila.',
        complianceBadges: ['LGPD', 'HIPAA', 'CFM'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Healthcare.`,
      }}
      className={className}
    />
  );
}
