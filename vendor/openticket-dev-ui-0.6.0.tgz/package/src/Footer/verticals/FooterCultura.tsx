'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterCultura — vertical magenta (#db2777).
 *
 * Cobre teatro, museus, exposicoes, cinema, opera — produtor, curador, espectador, artista.
 */

const accent: VerticalAccent = {
  primary: '#db2777',
  emoji: '🎨',
  gradient: 'linear-gradient(90deg, #9d174d 0%, #db2777 50%, #f472b6 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Teatro', href: '/cultura/teatro' },
      { label: 'Museus', href: '/cultura/museus' },
      { label: 'Exposições', href: '/cultura/exposicoes' },
      { label: 'Cinema', href: '/cultura/cinema' },
      { label: 'Ópera & Dança', href: '/cultura/opera-danca' },
      { label: 'Programação', href: '/cultura/programacao' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Meus ingressos', href: '/conta/ingressos' },
      { label: 'Assinaturas', href: '/conta/assinaturas' },
      { label: 'Lista de espera', href: '/conta/espera' },
      { label: 'Favoritos', href: '/conta/favoritos' },
      { label: 'Histórico', href: '/conta/historico' },
      { label: 'Acessibilidade', href: '/conta/acessibilidade' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Criar sessão', href: '/admin/sessoes/novo' },
      { label: 'Mapa de sala', href: '/admin/mapa' },
      { label: 'Curadoria', href: '/admin/curadoria' },
      { label: 'Bilheteria', href: '/admin/bilheteria' },
      { label: 'Patrocínios', href: '/admin/patrocinios' },
      { label: 'Lei Rouanet', href: '/admin/rouanet' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
  { emoji: '🎓', label: 'Educação', href: '/educacao' },
];

export interface FooterCulturaProps {
  role?: UserRole;
  className?: string;
}

export function FooterCultura({ role, className }: FooterCulturaProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'cultura');

  return (
    <FooterBase
      vertical="cultura"
      accent={accent}
      brand={{
        tagline: 'Da bilheteria à curadoria — cultura sem barreiras.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Cultura.`,
      }}
      className={className}
    />
  );
}
