'use client';

import * as React from 'react';
import { FooterBase } from '../FooterBase';
import { resolveRoleForVertical, useFooterUser } from '../FooterContext';
import type { FooterColumn, UserRole, VerticalAccent } from '../types';

/**
 * FooterEducacao — vertical azul (#2563eb).
 *
 * Cobre cursos, workshops, palestras e formaturas — escola, universidade, aluno, mentor.
 */

const accent: VerticalAccent = {
  primary: '#2563eb',
  emoji: '🎓',
  gradient: 'linear-gradient(90deg, #1e40af 0%, #2563eb 50%, #60a5fa 100%)',
};

const columns: FooterColumn[] = [
  {
    title: 'Descobrir',
    audience: 'consumer',
    links: [
      { label: 'Cursos', href: '/educacao/cursos' },
      { label: 'Workshops', href: '/educacao/workshops' },
      { label: 'Palestras', href: '/educacao/palestras' },
      { label: 'Mentores', href: '/educacao/mentores' },
      { label: 'Bootcamps', href: '/educacao/bootcamps' },
      { label: 'Formaturas', href: '/educacao/formaturas' },
    ],
  },
  {
    title: 'Sua conta',
    audience: 'consumer',
    links: [
      { label: 'Meus cursos', href: '/conta/cursos' },
      { label: 'Certificados', href: '/conta/certificados' },
      { label: 'Progresso', href: '/conta/progresso' },
      { label: 'Mentorias', href: '/conta/mentorias' },
      { label: 'Calendário', href: '/conta/calendario' },
      { label: 'Comunidade', href: '/conta/comunidade' },
    ],
  },
  {
    title: 'Gerenciar',
    audience: 'gestor',
    links: [
      { label: 'Criar curso', href: '/admin/cursos/novo' },
      { label: 'Turmas', href: '/admin/turmas' },
      { label: 'Certificados', href: '/admin/certificados' },
      { label: 'Mentores', href: '/admin/mentores' },
      { label: 'Pagamentos', href: '/admin/pagamentos' },
      { label: 'Relatórios', href: '/admin/relatorios' },
    ],
  },
  {
    title: 'Suporte',
    audience: 'all',
    links: [
      { label: 'Central de ajuda', href: '/ajuda' },
      { label: 'WhatsApp', href: 'https://wa.me/5500000000000', external: true },
      { label: 'Termos', href: '/termos' },
      { label: 'Privacidade', href: '/privacidade' },
    ],
  },
];

const switcher = [
  { emoji: '🎪', label: 'Eventos', href: '/eventos' },
  { emoji: '🍔', label: 'Gastronomia', href: '/gastronomia' },
  { emoji: '⚽', label: 'Esportes', href: '/esportes' },
  { emoji: '🛒', label: 'Varejo', href: '/varejo' },
  { emoji: '🎨', label: 'Cultura', href: '/cultura' },
  { emoji: '⛪', label: 'Igreja', href: '/igreja' },
];

export interface FooterEducacaoProps {
  role?: UserRole;
  className?: string;
}

export function FooterEducacao({ role, className }: FooterEducacaoProps) {
  const ctx = useFooterUser();
  const resolvedRole = role ?? resolveRoleForVertical(ctx, 'educacao');

  return (
    <FooterBase
      vertical="educacao"
      accent={accent}
      brand={{
        tagline: 'Do bootcamp à formatura — educação que transforma.',
        complianceBadges: ['LGPD', 'PCI-DSS'],
      }}
      columns={columns}
      role={resolvedRole}
      switcher={switcher}
      legal={{
        copyright: `© ${new Date().getFullYear()} OpenTicket Educação.`,
      }}
      className={className}
    />
  );
}
