// Footer System — Wave 7 — Public surface
export * from './types';
export { FooterBase } from './FooterBase';
export { FooterInstitutional } from './FooterInstitutional';
export {
  FooterUserProvider,
  useFooterUser,
  resolveRoleForVertical,
} from './FooterContext';
export type {
  FooterUserContextValue,
  FooterUserProviderProps,
} from './FooterContext';
export { FooterEventos } from './verticals/FooterEventos';
export { FooterGastronomia } from './verticals/FooterGastronomia';
export { FooterRelacionamentos } from './verticals/FooterRelacionamentos';
export { FooterCultura } from './verticals/FooterCultura';
export { FooterEducacao } from './verticals/FooterEducacao';
export { FooterEsportes } from './verticals/FooterEsportes';
export { FooterHealthcare } from './verticals/FooterHealthcare';
export { FooterIgreja } from './verticals/FooterIgreja';
export { FooterVarejo } from './verticals/FooterVarejo';
