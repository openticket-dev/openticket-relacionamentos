'use client';

import { createContext, useContext, type ReactNode } from 'react';
import type { UserRole, VerticalId } from './types';

/**
 * FooterContext — dual-context skeleton (Sprint 7.9).
 *
 * Holds the viewer's role (anonymous | consumer | gestor | dual) per vertical.
 * The full hook (`useUserVerticalContext`) lives in the consumer app and
 * derives the role from auth state + memberships. Here we only expose the
 * shape so the UI package can render the right columns without depending on
 * the app's auth layer.
 *
 * IMPORTANT: business logic (auth, memberships) is NOT in this package.
 * This is a skeleton — implementers must wire a provider in the host app.
 */
export interface FooterUserContextValue {
  role: UserRole;
  /** When the user is a gestor of one or more verticals, list them. */
  managedVerticals?: VerticalId[];
  /** When the user has a consumer profile in one or more verticals, list them. */
  consumerVerticals?: VerticalId[];
}

const defaultValue: FooterUserContextValue = {
  role: 'anonymous',
  managedVerticals: [],
  consumerVerticals: [],
};

const FooterUserContext =
  createContext<FooterUserContextValue>(defaultValue);

export interface FooterUserProviderProps {
  value: FooterUserContextValue;
  children: ReactNode;
}

export function FooterUserProvider({
  value,
  children,
}: FooterUserProviderProps) {
  return (
    <FooterUserContext.Provider value={value}>
      {children}
    </FooterUserContext.Provider>
  );
}

/**
 * useFooterUser — read the current viewer role + membership lists.
 * Returns the default `anonymous` shape when no provider is mounted.
 */
export function useFooterUser(): FooterUserContextValue {
  return useContext(FooterUserContext);
}

/**
 * resolveRoleForVertical — derive the role to render for a given vertical
 * based on the viewer's memberships.
 *
 * Rules (from kuffinho-masterplan.md Sprint 7.9):
 *   - anonymous → 'anonymous' (Descobrir + "Crie sua conta" + Suporte)
 *   - consumer-only of this vertical → 'consumer'
 *   - gestor-only of this vertical → 'gestor'
 *   - both → 'dual' (Descobrir + Sua conta + Gerenciar + Suporte)
 */
export function resolveRoleForVertical(
  ctx: FooterUserContextValue,
  vertical: VerticalId,
): UserRole {
  const isConsumer = ctx.consumerVerticals?.includes(vertical) ?? false;
  const isGestor = ctx.managedVerticals?.includes(vertical) ?? false;
  if (isConsumer && isGestor) return 'dual';
  if (isGestor) return 'gestor';
  if (isConsumer) return 'consumer';
  return 'anonymous';
}
