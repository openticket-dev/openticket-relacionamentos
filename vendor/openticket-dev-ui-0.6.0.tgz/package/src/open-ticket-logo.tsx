import * as React from 'react';

export function OpenTicketLogo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Efeito espiral (Espiral de Arquimedes) matemático */}
      {Array.from({ length: 32 }).map((_, i) => {
        const angle = i * 0.45; // Incremento angular para giro suave (~25 deg)
        const distance = 4 + i * 1.2; // Raio orbitando para longe do centro
        const cx = 50 + distance * Math.cos(angle);
        const cy = 50 + distance * Math.sin(angle);
        const r = 1 + i * 0.15; // Pontos ganham corpo de fora pra dentro
        
        return (
          <circle 
            key={i} 
            cx={cx} 
            cy={cy} 
            r={r} 
            opacity={0.3 + (i / 32) * 0.7} // Efeito visual de nascer do ponto zero
          />
        );
      })}
      {/* Núcleo inicial da espiral */}
      <circle cx="50" cy="50" r="2.5" opacity="0.4" />
    </svg>
  );
}
