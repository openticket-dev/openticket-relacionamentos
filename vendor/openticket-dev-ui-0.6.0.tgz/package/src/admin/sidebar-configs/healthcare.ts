/**
 * Healthcare admin sidebar configuration.
 *
 * Mirror of the navigation today rendered by
 * openticket-healthcare/src/components/admin/AdminSidebar.tsx (driven by
 * `adminSections` in `src/lib/admin-sections.ts`).
 *
 * Drives navigation inside `/healthcare/admin/*` (clínica / pacientes /
 * agenda / financeiro / config).
 *
 * NOTE: healthcare hoje renderiza um sidebar inline; este config alinha a
 * estrutura com o template do shell. A migração do AdminSidebar inline para o
 * shared AdminSidebar é sprint futura.
 */

import {
  Activity,
  Calendar,
  ClipboardList,
  DollarSign,
  LayoutDashboard,
  Lock,
  Megaphone,
  Settings,
  Stethoscope,
  UserPlus,
  Users,
  UsersRound,
  Video,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const healthcareSidebarConfig: AdminSidebarConfig = {
  vertical: "healthcare",
  label: "Healthcare",
  accent: "#0ea5e9",
  accentSoft: "rgba(14,165,233,0.12)",
  gradient: "linear-gradient(135deg, #0ea5e9, #0369a1)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/healthcare/admin/dashboard", icon: LayoutDashboard },
      ],
    },
    {
      title: "CLÍNICA",
      items: [
        { label: "Profissionais", href: "/healthcare/admin/profissionais", icon: Stethoscope },
        { label: "Especialidades", href: "/healthcare/admin/especialidades", icon: ClipboardList },
        { label: "Telemedicina", href: "/healthcare/admin/telemedicina", icon: Video },
      ],
    },
    {
      title: "AGENDA",
      items: [
        { label: "Consultas", href: "/healthcare/admin/consultas", icon: Calendar },
        { label: "Exames", href: "/healthcare/admin/exames", icon: Activity },
      ],
    },
    {
      title: "PACIENTES",
      items: [
        { label: "Pacientes", href: "/healthcare/admin/pacientes", icon: Users },
        { label: "Novo Cadastro", href: "/healthcare/admin/pacientes/novo", icon: UserPlus },
        { label: "Planos de Saúde", href: "/healthcare/admin/planos", icon: ClipboardList },
      ],
    },
    {
      title: "OPERAÇÃO",
      items: [
        { label: "Equipe", href: "/healthcare/admin/equipe", icon: UsersRound },
        { label: "Marketing", href: "/healthcare/admin/marketing", icon: Megaphone },
        { label: "Financeiro", href: "/healthcare/admin/finance", icon: DollarSign },
      ],
    },
    {
      title: "CONFIG",
      items: [
        { label: "Geral", href: "/healthcare/admin/config", icon: Settings },
        { label: "Roles", href: "/healthcare/admin/config/roles", icon: Lock },
      ],
    },
  ],
};
