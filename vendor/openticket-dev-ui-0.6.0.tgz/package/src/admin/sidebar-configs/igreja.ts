/**
 * Igreja admin sidebar configuration.
 *
 * Mirror of the NAV defined inline at
 * openticket-igreja/src/app/(admin)/layout.tsx (OT-LR-IGREJA-1, 2026-05-13).
 *
 * Drives navigation inside `/igreja/admin/*` (pastoral / comunidade /
 * sacramentos / doações / transparência / config).
 *
 * Sprint OT-LR-IGREJA-1 expanded from 10 to 33 entries; 5 dedup redirects
 * mapeados em /admin/{oracao,batismos,casamentos,crisma,comunhao}.
 */

import {
  Award,
  BadgeCheck,
  BookHeart,
  Building2,
  Calendar,
  CalendarDays,
  CalendarHeart,
  Church,
  Coins,
  Cross,
  DollarSign,
  Droplet,
  Eye,
  Heart,
  LayoutDashboard,
  Lock,
  Megaphone,
  Palette,
  PlaySquare,
  Plug,
  Plus,
  Radio,
  Receipt,
  RefreshCcw,
  Scroll,
  Settings,
  Stethoscope,
  TrendingDown,
  Users,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const igrejaSidebarConfig: AdminSidebarConfig = {
  vertical: "igreja",
  label: "Igreja",
  accent: "#fbbf24",
  accentSoft: "rgba(251,191,36,0.12)",
  gradient: "linear-gradient(135deg, #fbbf24, #d97706)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/igreja/admin/dashboard", icon: LayoutDashboard },
      ],
    },
    {
      title: "PASTORAL",
      items: [
        { label: "Calendário Litúrgico", href: "/igreja/admin/calendario", icon: Calendar },
        { label: "Agenda de Missas", href: "/igreja/admin/missas", icon: CalendarDays },
        { label: "Missa ao Vivo", href: "/igreja/admin/missa", icon: Radio },
        { label: "Acervo de Missas", href: "/igreja/admin/acervo", icon: PlaySquare },
        { label: "Lives", href: "/igreja/admin/lives", icon: Radio },
      ],
    },
    {
      title: "COMUNIDADE",
      items: [
        { label: "Paróquias", href: "/igreja/admin/paroquias", icon: Building2 },
        { label: "Nova Paróquia", href: "/igreja/admin/paroquias/new", icon: Plus },
        { label: "Comunidades", href: "/igreja/admin/paroquias/comunidades", icon: Users },
        { label: "Comunidade", href: "/igreja/admin/comunidade", icon: Users },
        { label: "Pedidos de Oração", href: "/igreja/admin/oracoes", icon: BookHeart },
        { label: "Intenções", href: "/igreja/admin/intencoes", icon: Award },
      ],
    },
    {
      title: "SACRAMENTOS",
      items: [
        { label: "Visão Geral", href: "/igreja/admin/sacramentos", icon: Award },
        { label: "Batismos", href: "/igreja/admin/sacramentos/batismos", icon: Droplet },
        { label: "Eucaristia", href: "/igreja/admin/sacramentos/eucaristia", icon: BadgeCheck },
        { label: "Crisma", href: "/igreja/admin/sacramentos/crisma", icon: Cross },
        { label: "Casamentos", href: "/igreja/admin/sacramentos/casamentos", icon: Heart },
        { label: "Confissões", href: "/igreja/admin/sacramentos/confissoes", icon: Cross },
        { label: "Unção dos Enfermos", href: "/igreja/admin/sacramentos/uncao-enfermos", icon: Stethoscope },
        { label: "Exéquias", href: "/igreja/admin/exequias", icon: Scroll },
      ],
    },
    {
      title: "DOAÇÕES",
      items: [
        { label: "Dízimos", href: "/igreja/admin/dizimos", icon: DollarSign },
        { label: "Avulsos", href: "/igreja/admin/dizimos/avulsos", icon: Coins },
        { label: "Recorrentes", href: "/igreja/admin/dizimos/recorrentes", icon: RefreshCcw },
        { label: "Campanhas de Dízimos", href: "/igreja/admin/dizimos/campanhas", icon: Megaphone },
        { label: "Comprovantes", href: "/igreja/admin/dizimos/comprovantes", icon: Receipt },
        { label: "Inadimplência", href: "/igreja/admin/dizimos/inadimplencia", icon: TrendingDown },
        { label: "Campanhas", href: "/igreja/admin/campanhas", icon: Megaphone },
      ],
    },
    {
      title: "TRANSPARÊNCIA",
      items: [
        { label: "Relatório Público", href: "/igreja/admin/transparencia", icon: Eye },
        { label: "Eventos da Paróquia", href: "/igreja/admin/eventos", icon: CalendarHeart },
      ],
    },
    {
      title: "CONFIG",
      items: [
        { label: "Geral", href: "/igreja/admin/config", icon: Settings },
        { label: "Diocese", href: "/igreja/admin/config/diocese", icon: Church },
        { label: "Branding", href: "/igreja/admin/config/branding", icon: Palette },
        { label: "Integrações", href: "/igreja/admin/config/integracoes", icon: Plug },
        { label: "Roles", href: "/igreja/admin/config/roles", icon: Lock },
      ],
    },
  ],
};
