/**
 * Central registry of admin sidebar configurations.
 *
 * OPS G8 (2026-05-28): mirror of `openticket-shell/src/components/admin/
 * sidebar-configs/*` published as part of `@openticket-dev/ui` so the
 * individual vertical apps can stop maintaining their own copy of the NAV
 * inline at `(admin)/layout.tsx`.
 *
 * Two forms exported per vertical:
 *
 * 1. `<vertical>SidebarConfig` — canonical config with shell-style hrefs
 *    (e.g. `/cultura/admin/dashboard`). Used by the shell itself when it
 *    mounts the cross-vertical preview.
 *
 * 2. `toLocalConfig(config)` — helper that rewrites every `<vertical>/admin`
 *    prefix to `/admin`. That's the shape vertical apps need because each
 *    vertical Next.js app mounts the admin at `/admin/*` (no vertical prefix).
 *
 * Items whose href does NOT start with `/<vertical>/admin` are kept as-is —
 * mostly cross-vertical links (e.g. `/crm` in eventos) and a few absolute
 * URLs. P4/P5: no silent transformation of unrelated entries.
 */

export type {
  AdminSidebarConfig,
  AdminSidebarItem,
  AdminSidebarSection,
} from "./types";

export { culturaSidebarConfig } from "./cultura";
export { educacaoSidebarConfig } from "./educacao";
export { esportesSidebarConfig } from "./esportes";
export { eventosSidebarConfig } from "./eventos";
export { gastronomiaSidebarConfig } from "./gastronomia";
export { healthcareSidebarConfig } from "./healthcare";
export { igrejaSidebarConfig } from "./igreja";
export { relacionamentosSidebarConfig } from "./relacionamentos";
export { varejoSidebarConfig } from "./varejo";

import type { AdminSidebarConfig } from "./types";
import { culturaSidebarConfig } from "./cultura";
import { educacaoSidebarConfig } from "./educacao";
import { esportesSidebarConfig } from "./esportes";
import { eventosSidebarConfig } from "./eventos";
import { gastronomiaSidebarConfig } from "./gastronomia";
import { healthcareSidebarConfig } from "./healthcare";
import { igrejaSidebarConfig } from "./igreja";
import { relacionamentosSidebarConfig } from "./relacionamentos";
import { varejoSidebarConfig } from "./varejo";

/**
 * Lookup map keyed by vertical slug.
 */
export const SIDEBAR_CONFIGS: Record<string, AdminSidebarConfig> = {
  cultura: culturaSidebarConfig,
  educacao: educacaoSidebarConfig,
  esportes: esportesSidebarConfig,
  eventos: eventosSidebarConfig,
  gastronomia: gastronomiaSidebarConfig,
  healthcare: healthcareSidebarConfig,
  igreja: igrejaSidebarConfig,
  relacionamentos: relacionamentosSidebarConfig,
  varejo: varejoSidebarConfig,
};

/**
 * Rewrites every `/<vertical>/admin/...` href in the config to `/admin/...`.
 *
 * Used by individual vertical Next.js apps that mount their admin at
 * `/admin/*` (no vertical prefix). Items whose href does not start with
 * `/<vertical>/admin` are left untouched — they are typically cross-vertical
 * deep-links (e.g. `/crm`) or absolute URLs.
 *
 * The original config is not mutated; a new object is returned.
 */
export function toLocalConfig(config: AdminSidebarConfig): AdminSidebarConfig {
  const prefix = `/${config.vertical}/admin`;
  return {
    ...config,
    sections: config.sections.map((section) => ({
      ...section,
      items: section.items.map((item) =>
        item.href.startsWith(prefix)
          ? { ...item, href: `/admin${item.href.slice(prefix.length)}` || "/admin" }
          : item,
      ),
    })),
  };
}
