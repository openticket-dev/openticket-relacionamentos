/**
 * Relacionamentos sidebar configuration.
 *
 * Mirror of the user-facing routes hoje navegáveis em
 * openticket-relacionamentos (perfil / matches / chat / buscar / denúncias /
 * premium / segurança).
 *
 * IMPORTANT: relacionamentos NÃO tem admin tradicional. Per CEO order
 * (OT-LEGACY-MIGRATION-MASTER-PLAN-2026-05-02): "catálogo B2B2C com sidebar
 * usuario direita + camaleão à esquerda". O UserSidebarRight
 * (src/components/UserSidebarRight.tsx) tem 4 sections (Perfil/Status/
 * Preferências/Privacidade) sem itens linkáveis — apenas widgets/toggles.
 *
 * Este config consolida os links REAIS de navegação do app no formato
 * AdminSidebarConfig pra alinhar com o template do shell. Estrutura
 * informativa; consumer pode ignorar este vertical se rodar admin-only.
 */

import {
  Heart,
  LayoutDashboard,
  MessageCircle,
  Search,
  Settings,
  ShieldAlert,
  Sparkles,
  User,
  UsersRound,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const relacionamentosSidebarConfig: AdminSidebarConfig = {
  vertical: "relacionamentos",
  label: "Relacionamentos",
  accent: "#ec4899",
  accentSoft: "rgba(236,72,153,0.12)",
  gradient: "linear-gradient(135deg, #ec4899, #be185d)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Início", href: "/", icon: LayoutDashboard },
      ],
    },
    {
      title: "DESCOBRIR",
      items: [
        { label: "Buscar", href: "/buscar", icon: Search },
        { label: "Matches", href: "/matches", icon: Heart },
      ],
    },
    {
      title: "SOCIAL",
      items: [
        { label: "Chat", href: "/chat", icon: MessageCircle },
      ],
    },
    {
      title: "CONTA",
      items: [
        { label: "Perfil", href: "/perfil", icon: User },
        { label: "Premium", href: "/premium", icon: Sparkles },
      ],
    },
    {
      title: "MODERAÇÃO",
      items: [
        { label: "Denúncias", href: "/denuncias", icon: ShieldAlert },
        // TODO(W-PARALELO-2-P9): CEO cravou href "/comunidade" (sidebar audit
        // 2026-05-28). Pendente: criar rota /comunidade em
        // openticket-relacionamentos (não existe hoje). Mantido /admin até a
        // rota ser criada — vai pro SPRINT-BACKLOG.
        { label: "Comunidade", href: "/admin", icon: UsersRound },
      ],
    },
    {
      title: "SEGURANÇA",
      items: [
        { label: "Segurança da Conta", href: "/admin/seguranca", icon: Settings },
      ],
    },
  ],
};
