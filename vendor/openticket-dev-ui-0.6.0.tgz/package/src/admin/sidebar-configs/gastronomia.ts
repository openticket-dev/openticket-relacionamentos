/**
 * Gastronomia admin sidebar configuration.
 *
 * Mirror of the NAV defined inline at
 * openticket-gastronomia/src/app/(admin)/layout.tsx (OT-LR-GASTRONOMIA).
 *
 * Drives navigation inside `/gastronomia/admin/*` (cardápio / mesas /
 * operação / inteligência / gestão).
 */

import {
  BarChart3,
  Beer,
  Bell,
  BookOpen,
  CalendarCheck,
  ClipboardList,
  DollarSign,
  Flame,
  GraduationCap,
  History,
  LayoutDashboard,
  LayoutGrid,
  ListChecks,
  Map,
  Megaphone,
  Package,
  QrCode,
  Settings,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Star,
  Tag,
  TrendingDown,
  Truck,
  UserCheck,
  Users,
  Users2,
  UtensilsCrossed,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const gastronomiaSidebarConfig: AdminSidebarConfig = {
  vertical: "gastronomia",
  label: "Gastronomia",
  accent: "#f59e0b",
  accentSoft: "rgba(245,158,11,0.12)",
  gradient: "linear-gradient(135deg, #f59e0b, #d97706)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/gastronomia/admin/dashboard", icon: LayoutDashboard },
      ],
    },
    {
      title: "CARDÁPIO",
      items: [
        { label: "Pratos", href: "/gastronomia/admin/cardapio", icon: UtensilsCrossed },
        { label: "Promoções", href: "/gastronomia/admin/cardapio/promotions", icon: Tag },
        { label: "Fichas Técnicas", href: "/gastronomia/admin/recipes", icon: ClipboardList },
        { label: "Cardápio Digital", href: "/gastronomia/admin/menu-admin", icon: BookOpen },
        { label: "Estoque", href: "/gastronomia/admin/estoque", icon: Package },
      ],
    },
    {
      title: "MESAS & SALÃO",
      items: [
        { label: "Mesas", href: "/gastronomia/admin/tables", icon: Map },
        { label: "Layout Mesas", href: "/gastronomia/admin/tables/layout", icon: LayoutGrid },
        { label: "Reservas", href: "/gastronomia/admin/reservas", icon: CalendarCheck },
        { label: "QR Codes", href: "/gastronomia/admin/qrcode", icon: QrCode },
      ],
    },
    {
      title: "OPERAÇÃO",
      items: [
        { label: "PDV", href: "/gastronomia/admin/pdv", icon: ShoppingCart },
        { label: "Pedidos ao Vivo", href: "/gastronomia/admin/orders", icon: Bell },
        { label: "Histórico Pedidos", href: "/gastronomia/admin/orders/history", icon: History },
        { label: "Cozinha KDS", href: "/gastronomia/admin/kitchen", icon: Flame },
        { label: "Garçom", href: "/gastronomia/admin/waiter", icon: UserCheck },
        { label: "Garçom Mesa", href: "/gastronomia/admin/waiter-table", icon: Users2 },
        { label: "Bar", href: "/gastronomia/admin/bar", icon: Beer },
        { label: "Delivery", href: "/gastronomia/admin/delivery", icon: Truck },
      ],
    },
    {
      title: "INTELIGÊNCIA",
      items: [
        { label: "Compra Inteligente", href: "/gastronomia/admin/smartbuy", icon: TrendingDown },
        { label: "Sugestões Compra", href: "/gastronomia/admin/smartbuy/suggestions", icon: Sparkles },
        { label: "Pedidos Compra", href: "/gastronomia/admin/smartbuy/orders", icon: ListChecks },
        { label: "Fornecedores", href: "/gastronomia/admin/smartbuy/suppliers", icon: Truck },
        { label: "Previsão Demanda", href: "/gastronomia/admin/demand", icon: BarChart3 },
        { label: "Avaliações", href: "/gastronomia/admin/reviews", icon: Star },
        { label: "Marketing", href: "/gastronomia/admin/marketing", icon: Megaphone },
      ],
    },
    {
      title: "GESTÃO",
      items: [
        { label: "Financeiro", href: "/gastronomia/admin/finance", icon: DollarSign },
        { label: "Equipe", href: "/gastronomia/admin/team", icon: Users },
        { label: "Permissões", href: "/gastronomia/admin/config/roles", icon: ShieldCheck },
        { label: "Configurações", href: "/gastronomia/admin/settings", icon: Settings },
        { label: "Tutorial Guiado", href: "/gastronomia/admin/tutorial", icon: GraduationCap },
      ],
    },
  ],
};
