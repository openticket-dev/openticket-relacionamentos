/**
 * Varejo admin sidebar configuration.
 *
 * Snapshot of the "default / unfiltered" NAV produced by the retail chameleon
 * provider at openticket-varejo/src/lib/retail-configs.ts (ALL_NAV_ITEMS).
 *
 * Drives navigation inside `/varejo/admin/*` (catálogo / vendas / serviços /
 * operação / crescimento / config).
 *
 * IMPORTANT: in the vertical app this list is filtered per RetailSubtype
 * (barbershop, gym, hortifruti…). This central mirror keeps the FULL surface
 * so the shell can render it for previews / multi-subtype dashboards. Per-
 * subtype filtering stays in the vertical (see retail-config.tsx).
 */

import {
  BellRing,
  Calculator,
  CalendarClock,
  CreditCard,
  DollarSign,
  Gift,
  Globe,
  GraduationCap,
  Layers,
  LayoutDashboard,
  Leaf,
  Lock,
  Megaphone,
  Package,
  ScanLine,
  Scissors,
  Settings,
  Shirt,
  ShoppingBag,
  Sparkles,
  Tag,
  TrendingDown,
  Truck,
  Undo2,
  UserCheck,
  UsersRound,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const varejoSidebarConfig: AdminSidebarConfig = {
  vertical: "varejo",
  label: "Varejo",
  accent: "#14b8a6",
  accentSoft: "rgba(20,184,166,0.12)",
  gradient: "linear-gradient(135deg, #14b8a6, #0f766e)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/varejo/admin/dashboard", icon: LayoutDashboard },
      ],
    },
    {
      title: "CATÁLOGO",
      items: [
        { label: "Produtos", href: "/varejo/admin/produtos", icon: Package },
        { label: "Estoque & Variações", href: "/varejo/admin/estoque", icon: Layers },
        { label: "Perecíveis & Validade", href: "/varejo/admin/fresh", icon: Leaf },
        { label: "Etiquetas", href: "/varejo/admin/labels", icon: Tag },
        { label: "Combinações", href: "/varejo/admin/outfits", icon: Shirt },
        { label: "Alertas de Preço", href: "/varejo/admin/price-alerts", icon: BellRing },
        { label: "Calculadora Markup", href: "/varejo/admin/markup", icon: Calculator },
      ],
    },
    {
      title: "VENDAS",
      items: [
        { label: "PDV & Checkout", href: "/varejo/admin/pdv", icon: CreditCard },
        { label: "Click & Collect", href: "/varejo/admin/click-collect", icon: ShoppingBag },
        { label: "Delivery", href: "/varejo/admin/delivery", icon: Truck },
        { label: "Omnichannel", href: "/varejo/admin/omnichannel", icon: Globe },
        { label: "Devoluções", href: "/varejo/admin/returns", icon: Undo2 },
      ],
    },
    {
      title: "SERVIÇOS",
      items: [
        { label: "Agendamentos", href: "/varejo/admin/scheduling", icon: CalendarClock },
        { label: "Profissionais", href: "/varejo/admin/professionals", icon: Scissors },
        { label: "Turmas & Aulas", href: "/varejo/admin/classes", icon: GraduationCap },
      ],
    },
    {
      title: "OPERAÇÃO",
      items: [
        { label: "Equipe", href: "/varejo/admin/equipe", icon: UsersRound },
        { label: "Vendedores & Comissão", href: "/varejo/admin/sellers", icon: UserCheck },
        { label: "Compra Inteligente", href: "/varejo/admin/smart-buy", icon: TrendingDown },
        { label: "Leitor NF", href: "/varejo/admin/nf-reader", icon: ScanLine },
      ],
    },
    {
      title: "CRESCIMENTO",
      items: [
        { label: "Fidelidade & Cashback", href: "/varejo/admin/loyalty", icon: Gift },
        { label: "Indicações", href: "/varejo/admin/referrals", icon: Megaphone },
        { label: "Marketing IA", href: "/varejo/admin/marketing", icon: Sparkles },
        { label: "Financeiro", href: "/varejo/admin/finance", icon: DollarSign },
      ],
    },
    {
      title: "CONFIG",
      items: [
        { label: "Configurações", href: "/varejo/admin/config", icon: Settings },
        { label: "Roles", href: "/varejo/admin/config/roles", icon: Lock },
        { label: "Tutorial Guiado", href: "/varejo/admin/tutorial", icon: GraduationCap },
      ],
    },
  ],
};
