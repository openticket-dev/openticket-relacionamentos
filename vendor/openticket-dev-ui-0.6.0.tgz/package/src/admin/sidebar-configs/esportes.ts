/**
 * Esportes admin sidebar configuration.
 *
 * Drives navigation inside `/esportes/admin/*` (M1 legacy migration).
 * Items map 1:1 with the M1 dashboards specified in the master plan
 * (Matches, Stadium, Tickets, Membership, Team, Store, Finance, Settings).
 */

import {
  LayoutDashboard,
  CalendarDays,
  Building2,
  Ticket,
  Users,
  Shirt,
  Store,
  DollarSign,
  Settings,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const esportesSidebarConfig: AdminSidebarConfig = {
  vertical: "esportes",
  label: "Esportes",
  accent: "#22c55e",
  accentSoft: "rgba(34,197,94,0.12)",
  gradient: "linear-gradient(135deg, #22c55e, #16a34a)",
  sections: [
    {
      title: "Operação",
      items: [
        {
          label: "Dashboard",
          href: "/esportes/admin",
          icon: LayoutDashboard,
        },
        {
          label: "Partidas",
          href: "/esportes/admin/matches",
          icon: CalendarDays,
        },
        {
          label: "Estádio",
          href: "/esportes/admin/stadium",
          icon: Building2,
        },
        {
          label: "Ingressos",
          href: "/esportes/admin/tickets",
          icon: Ticket,
        },
      ],
    },
    {
      title: "Sócios & Time",
      items: [
        {
          label: "Sócio-Torcedor",
          href: "/esportes/admin/membership",
          icon: Users,
        },
        {
          label: "Elenco",
          href: "/esportes/admin/team",
          icon: Shirt,
        },
      ],
    },
    {
      title: "Comercial",
      items: [
        {
          label: "Loja",
          href: "/esportes/admin/store",
          icon: Store,
        },
        {
          label: "Financeiro",
          href: "/esportes/admin/finance",
          icon: DollarSign,
        },
      ],
    },
    {
      title: "Sistema",
      items: [
        {
          label: "Configurações",
          href: "/esportes/admin/settings",
          icon: Settings,
        },
      ],
    },
  ],
};
