/**
 * Educação admin sidebar configuration.
 *
 * Mirror of the NAV defined inline at
 * openticket-educacao/src/app/(admin)/layout.tsx (OT-LR-EDUCACAO).
 *
 * Drives navigation inside `/educacao/admin/*` (cursos / matrículas / alunos /
 * conteúdo / engajamento / comercial / operação / config).
 */

import {
  AlertTriangle,
  Award,
  BookOpen,
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  DollarSign,
  FileSignature,
  FileText,
  GraduationCap,
  HelpCircle,
  LayoutDashboard,
  Lock,
  Megaphone,
  MessageSquare,
  Package,
  PlaySquare,
  Plug,
  Repeat,
  Settings,
  Tags,
  Upload,
  Users,
  UsersRound,
  Video,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const educacaoSidebarConfig: AdminSidebarConfig = {
  vertical: "educacao",
  label: "Educação",
  accent: "#3b82f6",
  accentSoft: "rgba(59,130,246,0.12)",
  gradient: "linear-gradient(135deg, #3b82f6, #1d4ed8)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/educacao/admin/dashboard", icon: LayoutDashboard },
      ],
    },
    {
      title: "ACADÊMICO",
      items: [
        { label: "Cursos", href: "/educacao/admin/cursos", icon: GraduationCap },
        { label: "Categorias", href: "/educacao/admin/cursos/categorias", icon: Tags },
        { label: "Ementas", href: "/educacao/admin/cursos/ementas", icon: FileText },
        { label: "Matrículas", href: "/educacao/admin/matriculas", icon: FileSignature },
        { label: "Confirmadas", href: "/educacao/admin/matriculas/confirmadas", icon: CheckCircle2 },
        { label: "Pendentes", href: "/educacao/admin/matriculas/pendentes", icon: Clock },
        { label: "Transferências", href: "/educacao/admin/matriculas/transferencias", icon: Repeat },
        { label: "Alunos", href: "/educacao/admin/alunos", icon: Users },
        { label: "Responsáveis", href: "/educacao/admin/alunos/responsaveis", icon: UsersRound },
        { label: "Aulas ao Vivo", href: "/educacao/admin/aulas-ao-vivo", icon: PlaySquare },
        { label: "Certificados", href: "/educacao/admin/certificados", icon: Award },
        { label: "Evasão", href: "/educacao/admin/evasao", icon: AlertTriangle },
      ],
    },
    {
      title: "CONTEÚDO",
      items: [
        { label: "Materiais", href: "/educacao/admin/materiais", icon: BookOpen },
        { label: "Upload Material", href: "/educacao/admin/materiais/upload", icon: Upload },
        { label: "Aulas", href: "/educacao/admin/aulas", icon: Video },
      ],
    },
    {
      title: "ENGAJAMENTO",
      items: [
        { label: "Agenda", href: "/educacao/admin/agenda", icon: Calendar },
        { label: "Comunidade", href: "/educacao/admin/comunidade", icon: MessageSquare },
      ],
    },
    {
      title: "COMERCIAL",
      items: [
        { label: "Financeiro", href: "/educacao/admin/financeiro", icon: DollarSign },
        { label: "Marketing", href: "/educacao/admin/marketing", icon: Megaphone },
        { label: "Produtos", href: "/educacao/admin/produtos", icon: Package },
      ],
    },
    {
      title: "OPERAÇÃO",
      items: [
        { label: "Equipe", href: "/educacao/admin/equipe", icon: UsersRound },
      ],
    },
    {
      title: "AJUDA",
      items: [
        { label: "Tutorial", href: "/educacao/admin/tutorial", icon: HelpCircle },
      ],
    },
    {
      title: "CONFIG",
      items: [
        { label: "Geral", href: "/educacao/admin/config", icon: Settings },
        { label: "Instituição", href: "/educacao/admin/config/instituicao", icon: Building2 },
        { label: "Integrações", href: "/educacao/admin/config/integracoes", icon: Plug },
        { label: "Roles", href: "/educacao/admin/config/roles", icon: Lock },
      ],
    },
  ],
};
