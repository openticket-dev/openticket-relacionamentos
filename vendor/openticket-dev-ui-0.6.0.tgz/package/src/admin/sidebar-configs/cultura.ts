/**
 * Cultura admin sidebar configuration.
 *
 * Mirror of the NAV defined inline at
 * openticket-cultura/src/app/(admin)/layout.tsx (OT-LR-CULTURA, 2026-05).
 *
 * Drives navigation inside `/cultura/admin/*`. Items map 1:1 with the dashboards
 * specified in the master plan (museu / acervo / vendas / marketing /
 * operação / config).
 *
 * NOTE: vertical repos still own their own copy. This file is the central
 * mirror — migration of imports is a follow-up sprint (see S4 PR body).
 */

import {
  Accessibility,
  BookOpen,
  Brush,
  Building2,
  CalendarDays,
  CreditCard,
  DollarSign,
  Frame,
  Globe,
  GraduationCap,
  Headphones,
  HelpCircle,
  Image,
  LayoutDashboard,
  Lock,
  MapPin,
  Megaphone,
  ScanLine,
  Settings,
  ShoppingBag,
  Ticket,
  Users,
  UsersRound,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const culturaSidebarConfig: AdminSidebarConfig = {
  vertical: "cultura",
  label: "Cultura",
  accent: "#a78bfa",
  accentSoft: "rgba(167,139,250,0.12)",
  gradient: "linear-gradient(135deg, #a78bfa, #7c3aed)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/cultura/admin/dashboard", icon: LayoutDashboard },
      ],
    },
    {
      title: "ACERVO",
      items: [
        { label: "Exibições", href: "/cultura/admin/exibicoes", icon: Image },
        { label: "Obras", href: "/cultura/admin/exibicoes/obras", icon: Frame },
        { label: "Curadores", href: "/cultura/admin/exibicoes/curadores", icon: Brush },
        { label: "Programação", href: "/cultura/admin/programacao", icon: CalendarDays },
        { label: "Material Educativo", href: "/cultura/admin/edu-material", icon: BookOpen },
        { label: "Audioguia", href: "/cultura/admin/audio", icon: Headphones },
        { label: "Visitas Guiadas", href: "/cultura/admin/guided-tours", icon: MapPin },
        { label: "Acessibilidade", href: "/cultura/admin/accessibility", icon: Accessibility },
      ],
    },
    {
      title: "VENDAS",
      items: [
        { label: "Ingressos", href: "/cultura/admin/tickets", icon: Ticket },
        { label: "Loja do Museu", href: "/cultura/admin/store", icon: ShoppingBag },
        { label: "Patrocinadores", href: "/cultura/admin/sponsors", icon: Building2 },
      ],
    },
    {
      title: "MARKETING",
      items: [
        { label: "Marketing IA", href: "/cultura/admin/marketing", icon: Megaphone },
        { label: "Educação Cultural", href: "/cultura/admin/education", icon: GraduationCap },
      ],
    },
    {
      title: "OPERAÇÃO",
      items: [
        { label: "Visitantes", href: "/cultura/admin/visitantes", icon: Users },
        { label: "Equipe", href: "/cultura/admin/equipe", icon: UsersRound },
        { label: "Cashless", href: "/cultura/admin/cashless", icon: CreditCard },
        { label: "Acesso & Catracas", href: "/cultura/admin/access", icon: ScanLine },
        { label: "Metaverso", href: "/cultura/admin/metaverse", icon: Globe },
        { label: "Assinaturas", href: "/cultura/admin/subscriptions", icon: CreditCard },
      ],
    },
    {
      title: "CONFIG",
      items: [
        { label: "Geral", href: "/cultura/admin/config", icon: Settings },
        { label: "Roles", href: "/cultura/admin/config/roles", icon: Lock },
        { label: "Financeiro", href: "/cultura/admin/finance", icon: DollarSign },
        { label: "Tutorial Guiado", href: "/cultura/admin/tutorial", icon: HelpCircle },
      ],
    },
  ],
};
