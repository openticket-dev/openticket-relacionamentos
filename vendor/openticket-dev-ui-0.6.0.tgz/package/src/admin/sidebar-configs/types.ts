/**
 * Shared types for admin sidebar configurations.
 *
 * Each vertical (esportes, eventos, gastronomia…) defines a SidebarConfig
 * that AdminLayout/AdminSidebar consume to render its navigation.
 */

import type { ComponentType } from "react";

export type AdminSidebarItem = {
  label: string;
  href: string;
  icon: ComponentType<{ className?: string; style?: React.CSSProperties }>;
  /** Optional badge label (e.g. "Beta", "3"). */
  badge?: string;
};

export type AdminSidebarSection = {
  title: string;
  items: AdminSidebarItem[];
};

export type AdminSidebarConfig = {
  vertical: string;
  /** Pretty label shown at the sidebar header. */
  label: string;
  /** Hex color used as accent (active item, gradient, focus). */
  accent: string;
  /** Soft RGBA used for hover backgrounds. */
  accentSoft: string;
  /** Linear gradient used in header / brand block. */
  gradient: string;
  sections: AdminSidebarSection[];
};
