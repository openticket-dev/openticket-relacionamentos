/**
 * Eventos admin sidebar configuration.
 *
 * Mirror of NAV_SECTIONS defined inline at
 * openticket-eventos/src/components/AuthenticatedLayout.tsx (audit Reversa
 * 2026-05-04: hrefs apontam para `/admin/<path>` quando a página existe sob
 * o admin route group; legacy paths preservados onde ainda não foram migrados).
 *
 * Drives navigation inside `/eventos/admin/*` + legacy top-level routes.
 *
 * NOTE: paths absolutos preservados do legacy (sem prefixar /eventos) — esses
 * são os hrefs que o app eventos já usa hoje. Mirror, não rewrite.
 */

import {
  Award,
  BadgeCheck,
  Bell,
  Bot,
  Building2,
  Camera,
  Contact,
  CreditCard,
  DollarSign,
  Eye,
  FileSignature,
  Fingerprint,
  Globe,
  GraduationCap,
  Layers,
  LayoutDashboard,
  ListMusic,
  Lock,
  Megaphone,
  Package,
  QrCode,
  Repeat,
  ScanFace,
  ScanLine,
  Settings,
  ShieldCheck,
  Store,
  Ticket,
  TrendingUp,
  Users,
  UsersRound,
  Wallet,
  Zap,
} from "lucide-react";

import type { AdminSidebarConfig } from "./types";

export const eventosSidebarConfig: AdminSidebarConfig = {
  vertical: "eventos",
  label: "Eventos",
  accent: "#a855f7",
  accentSoft: "rgba(168,85,247,0.12)",
  gradient: "linear-gradient(135deg, #7c3aed, #a855f7)",
  sections: [
    {
      title: "GERAL",
      items: [
        { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
        { label: "Eventos", href: "/admin/events", icon: Ticket },
      ],
    },
    {
      title: "VENDAS",
      items: [
        { label: "Ingressos", href: "/admin/access", icon: Ticket },
        { label: "Financeiro", href: "/admin/finance", icon: DollarSign },
        { label: "Saques / Payouts", href: "/admin/finance/payouts", icon: Wallet },
        { label: "CRM", href: "/crm", icon: Contact },
        { label: "Promoters", href: "/admin/promoters", icon: Users },
        { label: "Patrocinadores", href: "/admin/sponsorship", icon: Building2 },
        { label: "Marketplace Revenda", href: "/marketplace", icon: Repeat },
        { label: "Contratos", href: "/contracts", icon: FileSignature },
      ],
    },
    {
      title: "OPERAÇÃO",
      items: [
        { label: "PDV / Cashless", href: "/admin/cashless", icon: CreditCard },
        { label: "Operações", href: "/admin/operations", icon: Settings },
        { label: "Check-in", href: "/admin/operations/checkin", icon: Zap },
        { label: "Wallet & NFC", href: "/wallet-nfc", icon: Wallet },
        { label: "Estoque", href: "/stock", icon: Package },
        { label: "Pontos de Venda", href: "/pos", icon: Store },
        { label: "Acesso", href: "/access/gates", icon: ScanLine },
        { label: "Crowd Control", href: "/crowd-control", icon: Eye },
        { label: "Scanner QR", href: "/scanner", icon: QrCode },
        { label: "Equipe", href: "/team", icon: UsersRound },
        { label: "Credenciais", href: "/credentials", icon: BadgeCheck },
      ],
    },
    {
      title: "FERRAMENTAS",
      items: [
        { label: "Chatbot", href: "/chatbot", icon: Bot },
        { label: "Rider Técnico", href: "/rider", icon: ListMusic },
      ],
    },
    {
      title: "MARKETING",
      items: [
        { label: "Marketing IA", href: "/admin/marketing", icon: Megaphone },
        { label: "Reports", href: "/admin/reports", icon: TrendingUp },
        { label: "Notificações", href: "/notifications", icon: Bell },
        { label: "AR Marketing", href: "/ar-marketing", icon: Camera },
      ],
    },
    {
      title: "SEGURANÇA",
      items: [
        { label: "LGPD", href: "/admin/lgpd", icon: Fingerprint },
        { label: "Audit Log", href: "/admin/audit-log", icon: Lock },
        { label: "Anti-Fraude", href: "/antifraud", icon: ShieldCheck },
        { label: "Face ID", href: "/face-enrollment", icon: ScanFace },
      ],
    },
    {
      title: "INOVAÇÃO",
      items: [
        { label: "Metaverso", href: "/metaverse", icon: Globe },
        { label: "Blockchain", href: "/blockchain", icon: Layers },
        { label: "POAP", href: "/poap", icon: Award },
      ],
    },
    {
      title: "AJUDA",
      items: [
        { label: "Tutorial Guiado", href: "/dashboard/tutorial", icon: GraduationCap },
      ],
    },
    {
      title: "CONFIG",
      items: [
        { label: "Configurações", href: "/admin/settings", icon: Settings },
        { label: "Config Evento", href: "/event-config", icon: Settings },
        { label: "Permissões & RBAC", href: "/dashboard/settings/roles", icon: Lock },
      ],
    },
  ],
};
