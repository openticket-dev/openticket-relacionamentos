import { createContext, useContext } from "react";

export interface ThemeTokens {
  bg: string;
  sidebarBg: string;
  sidebarBorder: string;
  sidebarText: string;
  sidebarActiveText: string;
  sidebarActiveBg: string;
  sidebarActiveBorder: string;
  sidebarHoverBg: string;
  headerBg: string;
  headerBorder: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  divider: string;
  toggleBg: string;
  cardBg: string;
  cardBorder: string;
}

/**
 * Admin shell chrome tokens (consumed via inline styles in AdminLayout /
 * AdminSidebar). Values follow the Brand Book §3 cosmic palette so the admin
 * matches the rest of the app. Token NAMES are stable — only VALUES carry the
 * brand. Active accent = brand purple #a855f7 (168,85,247).
 */
export function getThemeTokens(isDark: boolean): ThemeTokens {
  return isDark
    ? {
        bg: "#07060d", // app bg canonical
        sidebarBg: "#0d0a18", // bg tier 2
        sidebarBorder: "#2a2342", // line
        sidebarText: "#9a93b5", // muted
        sidebarActiveText: "#ece9f5", // txt primary
        sidebarActiveBg: "rgba(168,85,247,0.10)", // purple #a855f7
        sidebarActiveBorder: "rgba(168,85,247,0.15)",
        sidebarHoverBg: "rgba(255,255,255,0.03)",
        headerBg: "rgba(7,6,13,0.85)", // #07060d
        headerBorder: "rgba(42,35,66,0.6)", // line
        text: "#ece9f5",
        textSecondary: "#9a93b5",
        textMuted: "#6f6790", // mut2
        divider: "#2a2342",
        toggleBg: "rgba(255,255,255,0.06)",
        cardBg: "#13101f", // card
        cardBorder: "#2a2342",
      }
    : {
        bg: "#fafaf9", // warm off-white
        sidebarBg: "#ffffff",
        sidebarBorder: "#e4e4e7",
        sidebarText: "#71717a",
        sidebarActiveText: "#18181b",
        sidebarActiveBg: "rgba(168,85,247,0.06)", // purple #a855f7
        sidebarActiveBorder: "rgba(168,85,247,0.12)",
        sidebarHoverBg: "rgba(0,0,0,0.02)",
        headerBg: "rgba(250,250,249,0.85)",
        headerBorder: "rgba(0,0,0,0.06)",
        text: "#18181b",
        textSecondary: "#52525b",
        textMuted: "#a1a1aa",
        divider: "#e4e4e7",
        toggleBg: "rgba(0,0,0,0.04)",
        cardBg: "#ffffff",
        cardBorder: "#e4e4e7",
      };
}

interface ThemeContextValue {
  isDark: boolean;
  toggleTheme: () => void;
  tokens: ThemeTokens;
}

export const AdminThemeContext = createContext<ThemeContextValue>({
  isDark: true,
  toggleTheme: () => {},
  tokens: getThemeTokens(true),
});

export const useAdminTheme = () => useContext(AdminThemeContext);
