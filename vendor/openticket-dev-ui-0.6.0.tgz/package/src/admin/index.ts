export { AdminLayout } from "./AdminLayout";
export { AdminSidebar } from "./AdminSidebar";
export { AdminThemeContext, useAdminTheme, getThemeTokens } from "./theme";
export type { ThemeTokens } from "./theme";
export type {
  AdminLayoutProps,
  AdminNavItem,
  AdminNavSection,
  AdminUser,
  AdminLinkProps,
} from "./types";

// OPS G8 — central sidebar registry (shared between shell and verticals).
export {
  SIDEBAR_CONFIGS,
  culturaSidebarConfig,
  educacaoSidebarConfig,
  esportesSidebarConfig,
  eventosSidebarConfig,
  gastronomiaSidebarConfig,
  healthcareSidebarConfig,
  igrejaSidebarConfig,
  relacionamentosSidebarConfig,
  varejoSidebarConfig,
  toLocalConfig,
} from "./sidebar-configs";
export type {
  AdminSidebarConfig,
  AdminSidebarItem,
  AdminSidebarSection,
} from "./sidebar-configs";
