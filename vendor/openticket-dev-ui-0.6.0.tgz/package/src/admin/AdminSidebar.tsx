"use client";

import React, { useEffect, useState } from "react";
import { ChevronRight, LogOut, Sun, Moon, X, Ticket } from "lucide-react";
import type { AdminNavSection, AdminUser, AdminLinkProps } from "./types";
import { useAdminTheme } from "./theme";

interface AdminSidebarProps {
  vertical: string;
  accentColor: string;
  sections: AdminNavSection[];
  pathname: string;
  LinkComponent: React.ComponentType<AdminLinkProps>;
  user: AdminUser | null;
  onLogout: () => void | Promise<void>;
  companyName?: string;
  open: boolean;
  onClose: () => void;
}

export function AdminSidebar({
  vertical,
  accentColor,
  sections,
  pathname,
  LinkComponent,
  user,
  onLogout,
  companyName,
  open,
  onClose,
}: AdminSidebarProps) {
  const { isDark, toggleTheme, tokens: t } = useAdminTheme();

  const isActive = (href: string) =>
    pathname === href ||
    (href !== "/admin" && href !== "/dashboard" && pathname.startsWith(href));

  return (
    <>
      {open && (
        <div
          className="lg:hidden fixed inset-0 z-30 bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      <aside
        className={[
          "fixed inset-y-0 left-0 z-40 w-60 flex flex-col transition-transform duration-200",
          open ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        ].join(" ")}
        style={{
          background: t.sidebarBg,
          borderRight: `1px solid ${t.sidebarBorder}`,
        }}
      >
        {/* Company header */}
        <div
          className="px-4 py-4 flex items-center gap-3"
          style={{ borderBottom: `1px solid ${t.sidebarBorder}` }}
        >
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{
              background: `linear-gradient(135deg, ${accentColor}, ${accentColor}cc)`,
            }}
          >
            <Ticket className="h-4 w-4 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <h1
              className="text-[13px] font-bold truncate leading-tight"
              style={{ color: t.text }}
            >
              {companyName || "OpenTicket"}
            </h1>
            <span
              className="inline-flex items-center text-[10px] font-semibold tracking-wider uppercase leading-none mt-0.5"
              style={{ color: accentColor }}
            >
              {vertical}
            </span>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1 rounded-md"
            style={{ color: t.textMuted }}
            aria-label="Fechar menu"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-3 overflow-y-auto space-y-4">
          {sections.map((section) => (
            <div key={section.title}>
              <p
                className="px-3 mb-1 text-[10px] font-semibold tracking-widest uppercase"
                style={{ color: t.textMuted }}
              >
                {section.title}
              </p>
              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.href);
                  return (
                    <LinkComponent
                      key={item.href}
                      href={item.href}
                      onClick={onClose}
                      className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all duration-150"
                      style={{
                        color: active ? t.sidebarActiveText : t.sidebarText,
                        background: active ? t.sidebarActiveBg : "transparent",
                      }}
                    >
                      {Icon && (
                        <Icon
                          className="h-4 w-4 shrink-0"
                          style={{ color: active ? accentColor : undefined }}
                        />
                      )}
                      {item.label}
                      {active && (
                        <ChevronRight className="h-3 w-3 ml-auto opacity-40" />
                      )}
                    </LinkComponent>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Theme toggle + User footer */}
        <div style={{ borderTop: `1px solid ${t.sidebarBorder}` }}>
          <div className="px-4 py-2 flex items-center justify-between">
            <span className="text-[11px]" style={{ color: t.textMuted }}>
              {isDark ? "Escuro" : "Claro"}
            </span>
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg transition-colors"
              style={{ background: t.toggleBg, color: t.textMuted }}
              aria-label="Alternar tema"
            >
              {isDark ? (
                <Sun className="h-3.5 w-3.5" />
              ) : (
                <Moon className="h-3.5 w-3.5" />
              )}
            </button>
          </div>
          <div className="px-3 pb-3">
            <div
              className="flex items-center gap-2.5 px-3 py-2 rounded-lg"
              style={{ background: t.sidebarHoverBg }}
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center text-[10px] font-black text-white shrink-0">
                {user?.name?.[0]?.toUpperCase() || "U"}
              </div>
              <div className="min-w-0 flex-1">
                <p
                  className="text-[12px] font-semibold truncate leading-tight"
                  style={{ color: t.text }}
                >
                  {user?.name || "Usuário"}
                </p>
                <p
                  className="text-[10px] truncate leading-tight"
                  style={{ color: t.textMuted }}
                >
                  {user?.role || user?.email || ""}
                </p>
              </div>
              <button
                onClick={onLogout}
                className="p-1.5 rounded-md transition-colors hover:opacity-80"
                style={{ color: t.textMuted }}
                aria-label="Sair"
                title="Sair"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
