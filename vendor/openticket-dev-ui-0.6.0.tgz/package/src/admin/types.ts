import type { ComponentType, ReactNode } from "react";

export interface AdminNavItem {
  label: string;
  href: string;
  icon?: ComponentType<{ className?: string; style?: React.CSSProperties }>;
  /** Optional roles required to see this item. Empty = visible to all authenticated. */
  roles?: string[];
  /** Open in new tab if external link */
  external?: boolean;
}

export interface AdminNavSection {
  title: string;
  items: AdminNavItem[];
}

export interface AdminUser {
  name?: string | null;
  email?: string | null;
  image?: string | null;
  role?: string | null;
}

export interface AdminLinkProps {
  href: string;
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
  children: ReactNode;
}

export interface AdminLayoutProps {
  /** Vertical label shown in sidebar header (e.g. "Eventos", "Gastronomia") */
  vertical: string;
  /** Vertical accent color (CSS) — defaults to violet */
  accentColor?: string;
  /** Sections of nav items, in display order */
  sections: AdminNavSection[];
  /** Current pathname (e.g. usePathname() in Next.js, location.pathname in others) */
  pathname: string;
  /** Link component (e.g. Next.js Link). Defaults to <a>. */
  LinkComponent?: ComponentType<AdminLinkProps>;
  /** Authenticated user — controls user-menu rendering */
  user: AdminUser | null;
  /** Logout callback */
  onLogout: () => void | Promise<void>;
  /** Optional company name (read from cookie ot_company_name in current pattern) */
  companyName?: string;
  /** Children = the routed page content */
  children: ReactNode;
  /** Initial dark mode (default true) — persists in localStorage */
  defaultDark?: boolean;
  /** Storage key for theme persistence (default "ot-admin-theme") */
  themeStorageKey?: string;
}
