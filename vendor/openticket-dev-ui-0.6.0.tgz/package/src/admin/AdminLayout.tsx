"use client";

import * as React from "react";
import { useEffect, useState } from "react";
import { Menu } from "lucide-react";
import type { AdminLayoutProps, AdminLinkProps } from "./types";
import { AdminThemeContext, getThemeTokens } from "./theme";
import { AdminSidebar } from "./AdminSidebar";

const DefaultLink: React.ComponentType<AdminLinkProps> = ({
  href,
  className,
  style,
  onClick,
  children,
}) => (
  <a href={href} className={className} style={style} onClick={onClick}>
    {children}
  </a>
);

/**
 * AdminLayout — shell shared admin layout for all OpenTicket verticals.
 *
 * Vertical-agnostic by design: receives nav sections as props, doesn't import
 * Next.js or any framework. Pass `LinkComponent={NextLink}` from Next.js apps
 * to get prefetch + client-side nav.
 *
 * @example
 *   import { AdminLayout } from '@openticket-dev/ui';
 *   import Link from 'next/link';
 *   import { usePathname } from 'next/navigation';
 *   import { useAuth } from '@openticket-dev/auth';
 *
 *   export default function Layout({ children }) {
 *     const pathname = usePathname() ?? '/admin';
 *     const { user, logout } = useAuth();
 *     return (
 *       <AdminLayout
 *         vertical="Gastronomia"
 *         accentColor="#f59e0b"
 *         pathname={pathname}
 *         LinkComponent={Link}
 *         user={user}
 *         onLogout={logout}
 *         sections={GASTRONOMY_NAV}
 *       >
 *         {children}
 *       </AdminLayout>
 *     );
 *   }
 */
export function AdminLayout({
  vertical,
  accentColor = "#a855f7",
  sections,
  pathname,
  LinkComponent = DefaultLink,
  user,
  onLogout,
  companyName,
  children,
  defaultDark = true,
  themeStorageKey = "ot-admin-theme",
}: AdminLayoutProps) {
  const [isDark, setIsDark] = useState(defaultDark);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Hydrate theme from localStorage
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const stored = window.localStorage.getItem(themeStorageKey);
      if (stored === "light") setIsDark(false);
      else if (stored === "dark") setIsDark(true);
    } catch {}
  }, [themeStorageKey]);

  const toggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      try {
        if (typeof window !== "undefined") {
          window.localStorage.setItem(themeStorageKey, next ? "dark" : "light");
        }
      } catch {}
      return next;
    });
  };

  const tokens = getThemeTokens(isDark);

  return (
    <AdminThemeContext.Provider value={{ isDark, toggleTheme, tokens }}>
      <div
        className="min-h-screen flex"
        style={{ background: tokens.bg, color: tokens.text }}
      >
        <AdminSidebar
          vertical={vertical}
          accentColor={accentColor}
          sections={sections}
          pathname={pathname}
          LinkComponent={LinkComponent}
          user={user}
          onLogout={onLogout}
          companyName={companyName}
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />

        <div className="flex-1 lg:ml-60 flex flex-col">
          {/* Header (mobile menu trigger) */}
          <header
            className="lg:hidden sticky top-0 z-20 px-4 py-3 flex items-center justify-between backdrop-blur-md"
            style={{
              background: tokens.headerBg,
              borderBottom: `1px solid ${tokens.headerBorder}`,
            }}
          >
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md"
              style={{ color: tokens.textMuted }}
              aria-label="Abrir menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <span
              className="text-[12px] font-semibold uppercase tracking-wider"
              style={{ color: accentColor }}
            >
              {vertical}
            </span>
            <span style={{ width: 24 }} />
          </header>

          <main className="flex-1 p-4 lg:p-6">{children}</main>
        </div>
      </div>
    </AdminThemeContext.Provider>
  );
}
